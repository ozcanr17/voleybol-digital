"""Uygulamayi baslatir ve arayuzu tarayicida acar.

    python run.py

Sunucu varsayilan olarak yalnizca bu bilgisayardan erisilebilir. Telefondaki
bir SMS yonlendirme uygulamasinin /api/sms adresine ulasabilmesi icin yerel aga
acmak gerekirse:

    python run.py --lan
"""

from __future__ import annotations

import argparse
import socket
import threading
import webbrowser

import uvicorn


def lan_ip() -> str:
    """Bu makinenin yerel agdaki adresi (telefonun ulasabilecegi adres)."""
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("8.8.8.8", 80))
        return sock.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        sock.close()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8777)
    parser.add_argument("--lan", action="store_true",
                        help="Yerel agdaki diger cihazlara da acik olsun.")
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args()

    host = "0.0.0.0" if args.lan else "127.0.0.1"
    shown = lan_ip() if args.lan else "127.0.0.1"
    url = f"http://{shown}:{args.port}/"

    print(f"\n  Arayuz: {url}")
    if args.lan:
        print(f"  Telefon SMS yonlendirme adresi: {url}api/sms")
    print("  Kapatmak icin Ctrl+C\n")

    if not args.no_browser:
        threading.Timer(1.0, webbrowser.open, args=(url,)).start()

    uvicorn.run("app.server:app", host=host, port=args.port, log_level="warning")


if __name__ == "__main__":
    main()
