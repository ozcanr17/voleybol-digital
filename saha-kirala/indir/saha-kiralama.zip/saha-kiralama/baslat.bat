@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo.
echo   Saha Kiralama Otomasyonu
echo   ------------------------
echo.

REM --- Python var mi? --------------------------------------------------------
set "PY="
py -3 --version >nul 2>&1
if not errorlevel 1 (
    set "PY=py -3"
    goto :python_ok
)
python --version >nul 2>&1
if not errorlevel 1 (
    set "PY=python"
    goto :python_ok
)

echo   [EKSIK] Python kurulu degil.
echo.
echo   Kurmak icin iki yol var:
echo.
echo     1^) Microsoft Store / komut satiri:
echo          winget install Python.Python.3.12
echo.
echo     2^) Elle: https://www.python.org/downloads/
echo        Kurulum ekraninda "Add python.exe to PATH" kutusunu MUTLAKA isaretleyin.
echo.
echo   Kurduktan sonra bu pencereyi kapatip baslat.bat dosyasini tekrar calistirin.
echo.
pause
exit /b 1

:python_ok
for /f "delims=" %%v in ('%PY% -c "import sys;print(sys.version.split()[0])"') do set "PYVER=%%v"
echo   [OK] Python %PYVER%

REM --- Chrome var mi? -------------------------------------------------------
set "CHROME="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "CHROME=1"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "CHROME=1"
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "CHROME=1"
if defined CHROME (
    echo   [OK] Google Chrome
) else (
    echo   [EKSIK] Google Chrome bulunamadi.
    echo          Kurun: https://www.google.com/chrome/
    echo          ^(veya: winget install Google.Chrome^)
    echo.
)

REM --- Sanal ortam ----------------------------------------------------------
if not exist ".venv\Scripts\python.exe" (
    echo   Python ortami olusturuluyor...
    %PY% -m venv .venv
    if errorlevel 1 (
        echo   [HATA] Sanal ortam olusturulamadi.
        pause
        exit /b 1
    )
)

REM --- Paketler -------------------------------------------------------------
".venv\Scripts\python.exe" -c "import selenium, fastapi, uvicorn, requests" >nul 2>&1
if errorlevel 1 (
    echo   Gerekli paketler kuruluyor, ilk calistirmada birkac dakika surebilir...
    ".venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
    ".venv\Scripts\python.exe" -m pip install --quiet -r requirements.txt
    if errorlevel 1 (
        echo   [HATA] Paketler kurulamadi. Internet baglantinizi kontrol edin.
        pause
        exit /b 1
    )
)
echo   [OK] Paketler hazir
echo.
echo   Baslatiliyor, tarayici birazdan acilacak...
echo   Kapatmak icin bu pencerede Ctrl+C
echo.

".venv\Scripts\python.exe" run.py %*

echo.
pause
