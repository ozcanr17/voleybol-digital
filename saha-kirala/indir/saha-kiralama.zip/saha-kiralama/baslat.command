#!/bin/bash
# macOS / Linux başlatıcı.
# macOS'ta ilk kullanımda Finder'da çift tıklamak için bir kez izin gerekir:
#     chmod +x baslat.command
# "Geliştirici doğrulanamadı" uyarısı çıkarsa: sağ tık > Aç > Aç.

cd "$(dirname "$0")" || exit 1

echo
echo "  Saha Kiralama Otomasyonu"
echo "  ------------------------"
echo

# --- Python var mı? ---------------------------------------------------------
PY=""
for candidate in python3.13 python3.12 python3.11 python3.10 python3; do
    if command -v "$candidate" >/dev/null 2>&1; then
        # 3.10+ olduğunu doğrula
        if "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)' 2>/dev/null; then
            PY="$candidate"
            break
        fi
    fi
done

if [ -z "$PY" ]; then
    echo "  [EKSİK] Python 3.10 veya üstü kurulu değil."
    echo
    if [ "$(uname)" = "Darwin" ]; then
        echo "  Kurmak için:"
        echo "    brew install python@3.12"
        echo "  Homebrew yoksa: https://www.python.org/downloads/macos/"
    else
        echo "  Kurmak için:  sudo apt install python3 python3-venv"
    fi
    echo
    echo "  Kurduktan sonra bu dosyayı tekrar çalıştırın."
    echo
    read -r -p "  Kapatmak için Enter..."
    exit 1
fi
echo "  [OK] Python $("$PY" -c 'import sys;print(sys.version.split()[0])')"

# --- Chrome var mı? ---------------------------------------------------------
if [ "$(uname)" = "Darwin" ]; then
    if [ -d "/Applications/Google Chrome.app" ]; then
        echo "  [OK] Google Chrome"
    else
        echo "  [EKSİK] Google Chrome bulunamadı."
        echo "          Kurun: https://www.google.com/chrome/"
        echo
    fi
elif command -v google-chrome >/dev/null 2>&1 || command -v chromium >/dev/null 2>&1; then
    echo "  [OK] Chrome/Chromium"
else
    echo "  [EKSİK] Chrome bulunamadı. Kurun: https://www.google.com/chrome/"
    echo
fi

# --- Sanal ortam ------------------------------------------------------------
if [ ! -x ".venv/bin/python" ]; then
    echo "  Python ortamı oluşturuluyor..."
    if ! "$PY" -m venv .venv; then
        echo "  [HATA] Sanal ortam oluşturulamadı."
        read -r -p "  Kapatmak için Enter..."
        exit 1
    fi
fi

# --- Paketler ---------------------------------------------------------------
if ! .venv/bin/python -c "import selenium, fastapi, uvicorn, requests" >/dev/null 2>&1; then
    echo "  Gerekli paketler kuruluyor, ilk çalıştırmada birkaç dakika sürebilir..."
    .venv/bin/python -m pip install --quiet --upgrade pip
    if ! .venv/bin/python -m pip install --quiet -r requirements.txt; then
        echo "  [HATA] Paketler kurulamadı. İnternet bağlantınızı kontrol edin."
        read -r -p "  Kapatmak için Enter..."
        exit 1
    fi
fi
echo "  [OK] Paketler hazır"
echo
echo "  Başlatılıyor, tarayıcı birazdan açılacak..."
echo "  Kapatmak için Ctrl+C"
echo

.venv/bin/python run.py "$@"
