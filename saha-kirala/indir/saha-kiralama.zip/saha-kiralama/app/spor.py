"""online.spor.istanbul kiralama akisi.

Eski koda gore kritik fark `snipe()`: seans acilis aninda aramayi tek sefer
tetikleyip DOM'u bosuna taramak yerine, seans gorunene kadar aramayi tekrar
tekrar tetikliyoruz. Sayfa ASP.NET WebForms postback'i ile yenilendigi icin
yeni istek atilmadan icerik asla degismez --- eski koddaki 20 denemelik dongu
bu yuzden hep ayni bos sayfayi tariyordu.
"""

from __future__ import annotations

import time

from selenium.common.exceptions import (
    ElementClickInterceptedException,
    ElementNotInteractableException,
    NoAlertPresentException,
    StaleElementReferenceException,
    TimeoutException,
    WebDriverException,
)
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from .browser import dismiss_overlays
from .timesync import Clock

BASE = "https://online.spor.istanbul"
SEARCH_BTN_ID = "pageContent_ucUrunArama_lbtnKiralikAra"


class SlotNotReleased(Exception):
    """Verilen sure icinde seans yayinlanmadi."""


class SporIstanbul:
    def __init__(self, driver, log=print, stop=None, clock: Clock | None = None):
        self.driver = driver
        self.log = log
        self.stop = stop or (lambda: False)
        self.clock = clock or Clock()
        self.wait = WebDriverWait(driver, 15)
        # Yoklama donguleri kendi zaman asimlarini yonetiyor; ortuk bekleme
        # her basarisiz aramada saniyeler kaybettirir.
        driver.implicitly_wait(0)
        self._research = "button"   # warmup sirasinda dogrulanir

    # ------------------------------------------------------------------
    # Yardimcilar
    # ------------------------------------------------------------------

    def _check_stop(self):
        if self.stop():
            raise WebDriverException("Kullanıcı tarafından iptal edildi.")

    def _find(self, by, value):
        """Tek eleman dondurur, yoksa None (istisna firlatmaz)."""
        found = self.driver.find_elements(by, value)
        return found[0] if found else None

    def _js_click(self, element):
        """JavaScript tiklamasi. Yalnizca `click` olayi gonderir."""
        self.driver.execute_script("arguments[0].click();", element)

    def _click(self, element):
        """Gercek fare tiklamasi.

        select2 acilir listeleri `mousedown` olayina tepki verir, `click`e
        degil. JS tiklamasi sadece `click` gonderdigi icin liste hic acilmiyor,
        sonra arama kutusunu bekleyen kod zaman asimina dusuyordu. Gercek
        tiklama tam olay dizisini (mousedown/mouseup/click) uretir.

        Ustumuze binen bir katman tiklamayi yerse once kaydirip tekrar
        deniyoruz, en son care olarak JS'e dusuyoruz.
        """
        try:
            element.click()
            return
        except (ElementClickInterceptedException, ElementNotInteractableException):
            pass

        dismiss_overlays(self.driver)
        self._scroll_to(element, -160)
        try:
            element.click()
        except Exception:
            self._js_click(element)

    def _click_by(self, by, value, timeout: float = 15.0):
        """Elemani bul ve tikla; DOM arada yenilenirse yeniden bulup dener.

        "Kiralama Yap"a tiklayinca sayfa sekme degistirip select2 bilesenlerini
        yeniden olusturuyor. Elemani bir kez bulup sonra tiklamaya calisirsak
        referans bayatliyor (`stale element reference`). Kor bir `sleep` yerine
        bayatlayinca yeniden buluyoruz --- hem daha hizli hem daha guvenilir.
        """
        son_hata = None
        bitis = time.time() + timeout
        while time.time() < bitis:
            self._check_stop()
            kalan = max(1.0, bitis - time.time())
            try:
                element = WebDriverWait(self.driver, kalan).until(
                    EC.element_to_be_clickable((by, value)))
                self._click(element)
                return element
            except StaleElementReferenceException as exc:
                son_hata = exc
                time.sleep(0.2)
        raise son_hata or TimeoutException(f"{value} tıklanamadı.")

    def kabul_et_alert(self, bekle: float = 0.0) -> str | None:
        """Ekranda yerel bir alert varsa metnini dondurup kabul eder.

        Site rezervasyon adiminda `alert()` kullaniyor. Bu kutu acikken hicbir
        WebDriver komutu calismaz, o yuzden beklendigi yerlerde temizliyoruz.
        Metni loga yaziyoruz --- site bir sey soyluyorsa kullanici gormeli.
        """
        bitis = time.time() + bekle
        while True:
            try:
                alert = self.driver.switch_to.alert
                metin = (alert.text or "").strip()
                alert.accept()
                if metin:
                    self.log(f"Site mesajı: {metin}")
                return metin
            except NoAlertPresentException:
                if time.time() >= bitis:
                    return None
                time.sleep(0.1)

    def _goto(self, url: str, deneme: int = 3) -> None:
        """Sayfayi acar; takilirsa yeniden dener.

        Chrome/chromedriver ara sira "Timed out receiving message from renderer"
        ile takiliyor --- olctugumuz kadariyla ~8 acilista 1. Bu, eklenen
        ayarlardan degil; orijinal yapilandirmada da ayni oranda oluyor.
        Gecici bir arizaya pes etmek yerine tekrar deniyoruz.
        """
        for i in range(1, deneme + 1):
            self._check_stop()
            try:
                self.driver.get(url)
                return
            except TimeoutException:
                if i == deneme:
                    raise
                self.log(f"Sayfa açılmadı ({i}/{deneme}), yeniden deneniyor...")
                # Yarim kalan yuklemeyi durdur, yoksa sonraki istek de takilabilir.
                try:
                    self.driver.execute_script("window.stop();")
                except Exception:
                    pass
                time.sleep(0.5)

    def _scroll_to(self, element, offset: int = -140):
        self.driver.execute_script(
            "const y = arguments[0].getBoundingClientRect().top + window.pageYOffset"
            " + arguments[1];"
            "window.scrollTo({top: y, behavior: 'instant'});",
            element, offset)

    def _goster(self, element, offset: int = -180, vurgula: bool = True) -> None:
        """Elemani ekrana getirir ve kisaca cerceveler.

        Kullanici otomasyonun ne yaptigini izleyebilsin diye: her adimda ilgili
        alana kayiyoruz. Vurgu 1.5 sn sonra kendiliginden siliniyor, sayfada iz
        birakmiyor.
        """
        try:
            self.driver.execute_script("""
              const el = arguments[0], off = arguments[1], vurgu = arguments[2];
              const y = el.getBoundingClientRect().top + window.pageYOffset + off;
              window.scrollTo({top: Math.max(0, y), behavior: 'smooth'});
              if (vurgu) {
                const eskiOutline = el.style.outline;
                const eskiOffset  = el.style.outlineOffset;
                el.style.outline = '3px solid #2b5cf0';
                el.style.outlineOffset = '3px';
                setTimeout(() => {
                  el.style.outline = eskiOutline;
                  el.style.outlineOffset = eskiOffset;
                }, 1500);
              }
            """, element, offset, vurgula)
            time.sleep(0.35)   # yumusak kaydirmanin oturmasi icin
        except WebDriverException:
            pass

    # ------------------------------------------------------------------
    # Giris ve gezinme
    # ------------------------------------------------------------------

    def login(self, tc: str, password: str) -> None:
        self._goto(f"{BASE}/uyegiris")
        dismiss_overlays(self.driver)

        self.wait.until(EC.presence_of_element_located(
            (By.XPATH, "//input[@placeholder='TC Kimlik No']"))).send_keys(tc)
        self.driver.find_element(
            By.XPATH, "//input[@placeholder='Şifre']").send_keys(password)

        dismiss_overlays(self.driver)
        self.driver.find_element(By.ID, "btnGirisYap").click()

        # Giris basariliysa anasayfaya duseriz; hata varsa sayfada kaliriz.
        try:
            WebDriverWait(self.driver, 20).until(
                lambda d: "uyegiris" not in d.current_url.lower())
        except TimeoutException:
            raise RuntimeError(
                "Giriş yapılamadı. T.C. Kimlik No / şifre hatalı olabilir ya da "
                "site ek doğrulama istemiş olabilir.")

        dismiss_overlays(self.driver)
        self.log("Giriş yapıldı.")

    def open_search_page(self) -> None:
        self._goto(f"{BASE}/anasayfa")
        dismiss_overlays(self.driver)

        self._click_by(
            By.XPATH,
            "//span[contains(@class,'nav-text') and normalize-space()='Kiralama Yap']")

        # Sekme degisimi select2 bilesenlerini yeniden olusturuyor. Filtre
        # widget'i gorunur olana kadar bekliyoruz --- orijinal koddaki
        # `time.sleep(1)` yerine, sabit sure yerine gercek kosul.
        try:
            self.wait.until(EC.visibility_of_element_located(
                (By.ID, "select2-ddlKiralikBransFiltre-container")))
        except TimeoutException:
            raise TimeoutException(
                "'Kiralama Yap' sekmesi açıldı ama filtre alanları görünmedi.") from None

        dismiss_overlays(self.driver)

    def _select_dropdown(self, select_id: str, option_text: str,
                         deneme: int = 3) -> None:
        """Select2 acilir listesinden bir secenek secer.

        Tum islem tekrarlanabilir: bir secim yapilinca sayfa postback ile
        yenilenip sonraki listenin secenekleri degisiyor, bu sirada elimizdeki
        referanslar bayatliyor. Tek tek elemani yeniden bulmak yetmedi ---
        islemin tamami bastan denenmeli.
        """
        for i in range(1, deneme + 1):
            try:
                self._select_dropdown_bir_kez(select_id, option_text)
            except StaleElementReferenceException:
                if i == deneme:
                    raise
                self.log(f"'{option_text}' seçilirken sayfa yenilendi, "
                         f"tekrar deneniyor ({i}/{deneme})...")
                time.sleep(0.5)
                continue

            if self._secili_mi(select_id, option_text):
                return
            if i == deneme:
                raise TimeoutException(
                    f"'{option_text}' seçilemedi ({select_id}). "
                    f"Bu isim listede olmayabilir.")
            self.log(f"'{option_text}' seçimi tutmadı, tekrar deneniyor "
                     f"({i}/{deneme})...")
            time.sleep(0.5)

    def _secili_mi(self, select_id: str, option_text: str,
                   bekle: float = 2.0) -> bool:
        """Secim gercekten yapisti mi? Sessiz basarisizliklari yakalar.

        select2 secilen metni hemen yazmiyor; bir kez bakip "tutmadi" demek
        gereksiz tekrara yol aciyordu. Kisa sure yoklayip oyle karar veriyoruz.
        """
        bitis = time.time() + bekle
        while True:
            try:
                el = self._find(By.ID, f"select2-{select_id}-container")
                gorunen = "" if el is None else (
                    el.get_attribute("title") or el.text or "").strip()
            except StaleElementReferenceException:
                gorunen = ""

            if gorunen and gorunen != "-- Seçiniz --":
                # Site secenegi bazen kisaltarak gosteriyor; iki yonlu bak.
                a, b = gorunen.casefold(), option_text.casefold()
                if a in b or b in a:
                    return True

            if time.time() >= bitis:
                return False
            time.sleep(0.15)

    def _select_dropdown_bir_kez(self, select_id: str, option_text: str) -> None:
        self._click_by(By.ID, f"select2-{select_id}-container")

        try:
            search_input = self.wait.until(EC.element_to_be_clickable(
                (By.XPATH, "//input[contains(@class,'select2-search__field')]")))
        except TimeoutException:
            # Ciplak TimeoutException'in mesaji bos; kullaniciya hicbir sey
            # anlatmiyor. Hangi alanda takildigimizi soyluyoruz.
            raise TimeoutException(
                f"'{option_text}' seçilemedi: açılır liste açılmadı "
                f"({select_id}). Sayfa yapısı değişmiş olabilir.") from None

        search_input.clear()
        search_input.send_keys(option_text)

        # select2 sonuc listesini doldurana kadar kisa bir es.
        try:
            WebDriverWait(self.driver, 5).until(
                lambda d: d.find_elements(
                    By.CSS_SELECTOR,
                    ".select2-results__option--highlighted, .select2-results__option[aria-selected]"))
        except TimeoutException:
            pass
        search_input.send_keys(Keys.ENTER)

    def select_filters(self, brans: str, tesis: str, salon: str | None) -> None:
        self._select_dropdown("ddlKiralikBransFiltre", brans)
        self._select_dropdown("ddlKiralikTesisFiltre", tesis)
        if salon:
            self._select_dropdown("ddlKiralikSalonFiltre", salon)
        self.log(f"Filtreler seçildi: {brans} / {tesis}" + (f" / {salon}" if salon else ""))

    # ------------------------------------------------------------------
    # Arama
    # ------------------------------------------------------------------

    def fire_search(self) -> bool:
        """Arama postback'ini tetikler. Yeni icerik geldiyse True."""
        self._check_stop()

        if self._research == "button":
            btn = self._find(By.ID, SEARCH_BTN_ID)
            if btn is not None:
                self._click(btn)
                return self._await_results()
            # Sonuc sayfasinda arama butonu yok --- form yeniden gonderimine gec.
            self._research = "postback"

        if self._research == "postback":
            return self._postback_refresh()

        return False

    def _postback_refresh(self) -> bool:
        """Sonuc sayfasinin formunu yeniden gonderir.

        ONEMLI: burada `driver.get(/satiskiralik)` KULLANILMAZ. Duz bir GET
        sunucudaki arama durumunu sifirliyor --- filtreler "-- Seciniz --"e
        donuyor ve sayfa bombos geliyor. Olcumle dogrulandi: GET sonrasi 0
        rezervasyon linki, __doPostBack sonrasi 18.

        `__doPostBack('','')` formu mevcut degerleriyle yeniden gonderir; ASP.NET
        ayni aramayi taze veriyle render eder ve filtreler korunur.
        """
        eski = self._find(By.TAG_NAME, "html")
        try:
            self.driver.execute_script(
                "if (window.__doPostBack) { __doPostBack('',''); }"
                "else { document.forms[0].submit(); }")
        except WebDriverException:
            return False

        # Postback tam sayfa yenilemesi: eski DOM bayatlayana kadar bekle, yoksa
        # henuz degismemis sayfayi tarayip "seans yok" sanabiliriz.
        if eski is not None:
            try:
                WebDriverWait(self.driver, 10).until(EC.staleness_of(eski))
            except TimeoutException:
                return False
        return self._await_results()

    def _await_results(self) -> bool:
        """Seans listesi paneli render olana kadar bekler."""
        try:
            WebDriverWait(self.driver, 10).until(
                lambda d: d.find_elements(
                    By.XPATH, "//h4[contains(@class,'panel-title')"
                              " and normalize-space()='Seans Listesi']"))
            return True
        except TimeoutException:
            return False

    def verify_results_page(self) -> None:
        self.wait.until(lambda d: "satiskiralik" in d.current_url.lower())
        dismiss_overlays(self.driver)

    def warm_up(self) -> None:
        """Acilis aninda hangi yontemin sayfayi tazeledigini onceden belirler.

        Kritik anda strateji denemek saniyeler kaybettirir; bunu hedef saatten
        once, bos zamanda hallediyoruz.
        """
        if self._find(By.ID, SEARCH_BTN_ID) is not None:
            self._research = "button"
            self.log("Tazeleme yöntemi: arama butonu.")
            return

        # Tazelemenin sonuclari KORUDUGUNU dogrula. Eskiden bunu kontrol
        # etmiyordum: secilen yontem sayfayi bosaltiyordu ve yoklamalar
        # dakikalarca bos sayfa tariyordu.
        onceki = self._slot_sayisi()
        self._research = "postback"
        self._postback_refresh()
        sonraki = self._slot_sayisi()

        if sonraki > 0 or onceki == 0:
            self.log(f"Tazeleme yöntemi: form yeniden gönderimi "
                     f"({sonraki} seans görünüyor).")
        else:
            raise RuntimeError(
                f"Sayfa tazelenince seanslar kayboluyor ({onceki} → {sonraki}). "
                f"Sitenin arama akışı değişmiş olabilir.")

    def _slot_sayisi(self) -> int:
        """Sayfada kac tane rezervasyon linki var? Tazelemenin saglamasi icin."""
        return len(self.driver.find_elements(
            By.CSS_SELECTOR, 'a[id*="lbRezervasyon"]'))

    # ------------------------------------------------------------------
    # Seans yakalama
    # ------------------------------------------------------------------

    def find_slot_button(self, date_text: str, time_text: str):
        """Seansin 'Rezervasyon' butonunu dondurur, yoksa None."""
        panel = self._find(
            By.XPATH,
            f"//div[contains(@class,'panel')][.//h3[contains(normalize-space(),'{date_text}')]]")
        if panel is None:
            return None

        blocks = panel.find_elements(
            By.XPATH,
            f".//span[contains(@class,'lblStyle') and contains(normalize-space(),'{time_text}')]"
            "/ancestor::div[contains(@class,'wellPlus')]")
        if not blocks:
            return None

        buttons = blocks[0].find_elements(
            By.XPATH, ".//a[contains(@id,'lbRezervasyon') and normalize-space()='Rezervasyon']")
        return buttons[0] if buttons else None

    def snipe(self, date_text: str, time_text: str, release_epoch: float,
              lead: float = 3.0, poll: float = 0.4, give_up_after: float = 180.0,
              on_poll_start=None):
        """Seans yayinlanana kadar aramayi tekrarlar, gorur gormez tiklar."""
        start_at = release_epoch - lead
        wait_secs = start_at - self.clock.now()
        if wait_secs > 0:
            self.log(f"Açılışa {wait_secs:.0f} sn var, bekleniyor "
                     f"(sunucu saati farkı {self.clock.offset:+.2f} sn).")
            self.clock.sleep_until(start_at, stop=self.stop)
        self._check_stop()

        # Bekleme bitti, asıl yarış başlıyor --- arayüz adımı burada değişmeli.
        if on_poll_start is not None:
            on_poll_start()
        self.log(f"Yoklama başladı: {date_text} {time_text}")
        deadline = release_epoch + give_up_after
        attempts = 0

        while self.clock.now() < deadline:
            self._check_stop()
            attempts += 1
            cycle_started = time.time()

            self.fire_search()
            dismiss_overlays(self.driver)

            button = self.find_slot_button(date_text, time_text)
            if button is not None:
                self._scroll_to(button, -160)
                self._js_click(button)
                self.log(f"Seans yakalandı ve tıklandı ({attempts}. yoklama).")
                # Site burada yerel bir alert aciyor; temizlemeden hicbir
                # komut calismaz.
                self.kabul_et_alert(bekle=3.0)
                return True

            if attempts % 10 == 0:
                self.log(f"{attempts} yoklama yapıldı, seans henüz yok...")

            # Ilk saniyeler gercek yaris; sonrasi degil. Seans 20 sn icinde
            # cikmadiysa milisaniye onemini yitirir, o yuzden yavaslatiyoruz.
            # Site Cloudflare arkasinda --- dakikalarca tam hizda yoklamak
            # hiz siniri yiyebilir.
            since_open = self.clock.now() - release_epoch
            interval = poll if since_open < 20 else (1.5 if since_open < 60 else 3.0)

            elapsed = time.time() - cycle_started
            if elapsed < interval:
                time.sleep(interval - elapsed)

        raise SlotNotReleased(
            f"{date_text} {time_text} seansı {give_up_after:.0f} sn içinde "
            f"yayınlanmadı ({attempts} yoklama). Seans başkası tarafından "
            f"kapılmış ya da bu saatte hiç açılmamış olabilir.")

    # ------------------------------------------------------------------
    # Rezervasyon
    # ------------------------------------------------------------------

    def confirm_reservation_modal(self, timeout: float = 10.0) -> bool:
        """Rezervasyon onay penceresindeki 'Tamam'a basar.

        Onemli: arama yalnizca modal kapsaminda yapiliyor. Eski kodun kullandigi
        `//button[contains(.,'Tamam')]` sayfa altindaki cerez bandindaki Tamam
        butonuyla da eslesiyordu ve yanlis butona basma riski vardi.
        """
        self.kabul_et_alert(bekle=2.0)

        modal_scope = (
            "//*[contains(@class,'modal') or contains(@class,'swal2-') "
            "or @role='dialog'][not(contains(@style,'display: none'))]"
            "//button[contains(normalize-space(),'Tamam')"
            " or contains(normalize-space(),'Onayla')"
            " or contains(normalize-space(),'Evet')]")

        # Modal ile formu AYNI ANDA bekliyoruz. Once modal'i zaman asimina kadar
        # beklemek, modal hic cikmadigi durumda (site yerel alert kullaniyor)
        # bosuna 10+ saniye kaybettiriyordu --- kritik anda seansi kaptiracak
        # kadar uzun.
        end = time.time() + timeout
        while time.time() < end:
            self._check_stop()

            for btn in self.driver.find_elements(By.XPATH, modal_scope):
                if btn.is_displayed():
                    self._js_click(btn)
                    self.log("Onay penceresi kabul edildi.")
                    return True

            if self._find(By.ID, "select2-ddlSatisTuru-container") is not None:
                self.log("Onay penceresi çıkmadı, doğrudan forma geçildi.")
                return False

            time.sleep(0.15)

        raise TimeoutException(
            "Rezervasyon onay penceresi de form da açılmadı.")

    def show_reservation_panel(self) -> None:
        """'Rezervasyon İşlemi' panelini ekrana getirir.

        Capa olarak Satis Turu alanini kullaniyoruz, metin eslestirmesini degil:
        'Rezervasyon İşlemi' ifadesi sayfanin baska yerlerinde de geciyor ve
        yanlis yere kaydiriyordu (alan ekranin 1365 px altinda kaliyordu).
        """
        try:
            anchor = self.wait.until(EC.presence_of_element_located(
                (By.ID, "select2-ddlSatisTuru-container")))
        except TimeoutException:
            return

        try:
            panel = anchor.find_element(
                By.XPATH, "ancestor::div[contains(@class,'panel')"
                          " or contains(@class,'card')][1]")
        except WebDriverException:
            panel = anchor
        self._goster(panel, offset=-120)

    def choose_satis_turu(self, satis_turu: str) -> None:
        container = self.wait.until(EC.element_to_be_clickable(
            (By.ID, "select2-ddlSatisTuru-container")))
        self._goster(container)

        self._select_dropdown("ddlSatisTuru", satis_turu)
        self.log(f"Satış türü seçildi: {satis_turu}")

        # Satis turu secilene kadar "Sepete Ekle" butonu ile yesil onay bandi
        # sayfada yok. Butona erken basmaya calismak yerine cikmasini bekliyoruz.
        try:
            WebDriverWait(self.driver, 15).until(
                lambda d: d.find_elements(By.ID, "pageContent_lbtnSepeteEkle"))
        except TimeoutException:
            raise TimeoutException(
                f"'{satis_turu}' seçildi ama 'Sepete Ekle' butonu çıkmadı. "
                f"Bu seans için bu kiralama türü geçerli olmayabilir.") from None

        bant = self._find(
            By.XPATH, "//*[contains(normalize-space(.),'Sepete ekleme işlemi')]"
                      "[not(.//*[contains(normalize-space(.),'Sepete ekleme işlemi')])]")
        if bant is not None:
            self.log(f"Site onayladı: {bant.text.strip()[:80]}")

    def add_to_cart(self) -> None:
        btn = self.wait.until(EC.presence_of_element_located(
            (By.ID, "pageContent_lbtnSepeteEkle")))
        dismiss_overlays(self.driver)
        self._goster(btn, offset=-220)
        self._click(btn)
        self.kabul_et_alert(bekle=3.0)
        self.log("Sepete ekle butonuna basıldı.")

    # ------------------------------------------------------------------
    # SMS dogrulama
    # ------------------------------------------------------------------

    def await_otp_field(self, timeout: float = 30.0):
        """SMS doğrulama alanı çıkana kadar bekler ve ekrana getirir."""
        try:
            field = WebDriverWait(self.driver, timeout).until(
                EC.visibility_of_element_located(
                    (By.ID, "pageContent_txtDogrulamaKodu")))
        except TimeoutException:
            raise TimeoutException(
                "Sepete eklendi ama SMS doğrulama alanı açılmadı. "
                "Sepeti elle kontrol edin.") from None

        # Baslikla birlikte gorunsun ki hangi numaraya kod gittigi okunabilsin.
        baslik = self._find(
            By.XPATH, "//*[contains(normalize-space(.),'SMS Doğrulama')]"
                      "[not(.//*[contains(normalize-space(.),'SMS Doğrulama')])]")
        self._goster(baslik if baslik is not None else field, offset=-160)

        bilgi = self._find(By.XPATH, "//*[contains(normalize-space(.),'gönderilen SMS kodunu')]"
                                     "[not(.//*[contains(normalize-space(.),'gönderilen SMS kodunu')])]")
        if bilgi is not None:
            self.log(bilgi.text.strip()[:120])
        return field

    def submit_otp(self, code: str) -> None:
        field = self.wait.until(EC.element_to_be_clickable(
            (By.ID, "pageContent_txtDogrulamaKodu")))
        self._goster(field, offset=-200)
        field.clear()
        field.send_keys(code)

        confirm = self._find(
            By.XPATH, "//*[self::a or self::button or self::input]"
                      "[contains(normalize-space(.),'Kodu Doğrula')"
                      " or contains(normalize-space(.),'Kodunu Doğrula')"
                      " or contains(@id,'DogrulamaKodu') and contains(@id,'lbtn')]")
        if confirm is None:
            raise RuntimeError("'Kodunu Doğrula' butonu bulunamadı.")
        self._goster(confirm, offset=-220)
        self._click(confirm)
        self.kabul_et_alert(bekle=3.0)
        self.log("Doğrulama kodu gönderildi.")
