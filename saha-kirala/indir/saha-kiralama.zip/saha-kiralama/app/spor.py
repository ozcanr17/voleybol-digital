"""online.spor.istanbul kiralama akisi.

Eski koda gore kritik fark `snipe()`: seans acilis aninda aramayi tek sefer
tetikleyip DOM'u bosuna taramak yerine, seans gorunene kadar aramayi tekrar
tekrar tetikliyoruz. Sayfa ASP.NET WebForms postback'i ile yenilendigi icin
yeni istek atilmadan icerik asla degismez --- eski koddaki 20 denemelik dongu
bu yuzden hep ayni bos sayfayi tariyordu.
"""

from __future__ import annotations

import time

from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

from .browser import dismiss_overlays
from .timesync import Clock

BASE = "https://online.spor.istanbul"
SEARCH_BTN_ID = "pageContent_ucUrunArama_lbtnKiralikAra"


class SlotNotReleased(Exception):
    """Verilen sure icinde seans yayinlanmadi."""


class SporIstanbul:
    def __init__(self, driver, log=print, stop=None, clock: Clock | None = None):
        self.driver = driver
        self.log = log
        self.stop = stop or (lambda: False)
        self.clock = clock or Clock()
        self.wait = WebDriverWait(driver, 15)
        # Yoklama donguleri kendi zaman asimlarini yonetiyor; ortuk bekleme
        # her basarisiz aramada saniyeler kaybettirir.
        driver.implicitly_wait(0)
        self._research = "button"   # warmup sirasinda dogrulanir

    # ------------------------------------------------------------------
    # Yardimcilar
    # ------------------------------------------------------------------

    def _check_stop(self):
        if self.stop():
            raise WebDriverException("Kullanıcı tarafından iptal edildi.")

    def _find(self, by, value):
        """Tek eleman dondurur, yoksa None (istisna firlatmaz)."""
        found = self.driver.find_elements(by, value)
        return found[0] if found else None

    def _js_click(self, element):
        self.driver.execute_script("arguments[0].click();", element)

    def _scroll_to(self, element, offset: int = -140):
        self.driver.execute_script(
            "const y = arguments[0].getBoundingClientRect().top + window.pageYOffset"
            " + arguments[1];"
            "window.scrollTo({top: y, behavior: 'instant'});",
            element, offset)

    # ------------------------------------------------------------------
    # Giris ve gezinme
    # ------------------------------------------------------------------

    def login(self, tc: str, password: str) -> None:
        self.driver.get(f"{BASE}/uyegiris")
        dismiss_overlays(self.driver)

        self.wait.until(EC.presence_of_element_located(
            (By.XPATH, "//input[@placeholder='TC Kimlik No']"))).send_keys(tc)
        self.driver.find_element(
            By.XPATH, "//input[@placeholder='Şifre']").send_keys(password)

        dismiss_overlays(self.driver)
        self.driver.find_element(By.ID, "btnGirisYap").click()

        # Giris basariliysa anasayfaya duseriz; hata varsa sayfada kaliriz.
        try:
            WebDriverWait(self.driver, 20).until(
                lambda d: "uyegiris" not in d.current_url.lower())
        except TimeoutException:
            raise RuntimeError(
                "Giriş yapılamadı. T.C. Kimlik No / şifre hatalı olabilir ya da "
                "site ek doğrulama istemiş olabilir.")

        dismiss_overlays(self.driver)
        self.log("Giriş yapıldı.")

    def open_search_page(self) -> None:
        self.driver.get(f"{BASE}/anasayfa")
        dismiss_overlays(self.driver)
        self.wait.until(EC.element_to_be_clickable((
            By.XPATH,
            "//span[contains(@class,'nav-text') and normalize-space()='Kiralama Yap']"
        ))).click()
        dismiss_overlays(self.driver)

    def _select_dropdown(self, select_id: str, option_text: str) -> None:
        container = self.wait.until(
            EC.element_to_be_clickable((By.ID, f"select2-{select_id}-container")))
        self._js_click(container)

        search_input = self.wait.until(EC.element_to_be_clickable(
            (By.XPATH, "//input[contains(@class,'select2-search__field')]")))
        search_input.clear()
        search_input.send_keys(option_text)

        # select2 sonuc listesini doldurana kadar kisa bir es.
        try:
            WebDriverWait(self.driver, 5).until(
                lambda d: d.find_elements(
                    By.CSS_SELECTOR,
                    ".select2-results__option--highlighted, .select2-results__option[aria-selected]"))
        except TimeoutException:
            pass
        search_input.send_keys(Keys.ENTER)

    def select_filters(self, brans: str, tesis: str, salon: str | None) -> None:
        self._select_dropdown("ddlKiralikBransFiltre", brans)
        self._select_dropdown("ddlKiralikTesisFiltre", tesis)
        if salon:
            self._select_dropdown("ddlKiralikSalonFiltre", salon)
        self.log(f"Filtreler seçildi: {brans} / {tesis}" + (f" / {salon}" if salon else ""))

    # ------------------------------------------------------------------
    # Arama
    # ------------------------------------------------------------------

    def fire_search(self) -> bool:
        """Arama postback'ini tetikler. Yeni icerik geldiyse True."""
        self._check_stop()

        if self._research == "button":
            btn = self._find(By.ID, SEARCH_BTN_ID)
            if btn is not None:
                self._js_click(btn)
                return self._await_results()
            # Sonuc sayfasinda arama butonu yoksa yeniden yukleme stratejisine gec.
            self._research = "reload"

        if self._research == "reload":
            # Sorgu parametresi her seferinde degisiyor: aradaki hicbir katman
            # (Chrome, vekil sunucu, CDN) onceki yaniti geri veremesin.
            self.driver.get(f"{BASE}/satiskiralik?_={int(time.time() * 1000)}")
            return self._await_results()

        return False

    def _await_results(self) -> bool:
        """Seans listesi paneli render olana kadar bekler."""
        try:
            WebDriverWait(self.driver, 10).until(
                lambda d: d.find_elements(
                    By.XPATH, "//h4[contains(@class,'panel-title')"
                              " and normalize-space()='Seans Listesi']"))
            return True
        except TimeoutException:
            return False

    def verify_results_page(self) -> None:
        self.wait.until(lambda d: "satiskiralik" in d.current_url.lower())
        dismiss_overlays(self.driver)

    def warm_up(self) -> None:
        """Acilis aninda hangi yontemin sayfayi tazeledigini onceden belirler.

        Kritik anda strateji denemek saniyeler kaybettirir; bunu hedef saatten
        once, bos zamanda hallediyoruz.
        """
        if self._find(By.ID, SEARCH_BTN_ID) is not None:
            self._research = "button"
            self.log("Tazeleme yöntemi: arama butonu (hızlı).")
            return
        self._research = "reload"
        if self.fire_search():
            self.log("Tazeleme yöntemi: sayfa yeniden yükleme.")
        else:
            self.log("UYARI: sayfa tazeleme doğrulanamadı, yine de denenecek.")

    # ------------------------------------------------------------------
    # Seans yakalama
    # ------------------------------------------------------------------

    def find_slot_button(self, date_text: str, time_text: str):
        """Seansin 'Rezervasyon' butonunu dondurur, yoksa None."""
        panel = self._find(
            By.XPATH,
            f"//div[contains(@class,'panel')][.//h3[contains(normalize-space(),'{date_text}')]]")
        if panel is None:
            return None

        blocks = panel.find_elements(
            By.XPATH,
            f".//span[contains(@class,'lblStyle') and contains(normalize-space(),'{time_text}')]"
            "/ancestor::div[contains(@class,'wellPlus')]")
        if not blocks:
            return None

        buttons = blocks[0].find_elements(
            By.XPATH, ".//a[contains(@id,'lbRezervasyon') and normalize-space()='Rezervasyon']")
        return buttons[0] if buttons else None

    def snipe(self, date_text: str, time_text: str, release_epoch: float,
              lead: float = 3.0, poll: float = 0.4, give_up_after: float = 180.0,
              on_poll_start=None):
        """Seans yayinlanana kadar aramayi tekrarlar, gorur gormez tiklar."""
        start_at = release_epoch - lead
        wait_secs = start_at - self.clock.now()
        if wait_secs > 0:
            self.log(f"Açılışa {wait_secs:.0f} sn var, bekleniyor "
                     f"(sunucu saati farkı {self.clock.offset:+.2f} sn).")
            self.clock.sleep_until(start_at, stop=self.stop)
        self._check_stop()

        # Bekleme bitti, asıl yarış başlıyor --- arayüz adımı burada değişmeli.
        if on_poll_start is not None:
            on_poll_start()
        self.log(f"Yoklama başladı: {date_text} {time_text}")
        deadline = release_epoch + give_up_after
        attempts = 0

        while self.clock.now() < deadline:
            self._check_stop()
            attempts += 1
            cycle_started = time.time()

            self.fire_search()
            dismiss_overlays(self.driver)

            button = self.find_slot_button(date_text, time_text)
            if button is not None:
                self._scroll_to(button, -160)
                self._js_click(button)
                self.log(f"Seans yakalandı ve tıklandı ({attempts}. yoklama).")
                return True

            if attempts % 10 == 0:
                self.log(f"{attempts} yoklama yapıldı, seans henüz yok...")

            # Ilk saniyeler gercek yaris; sonrasi degil. Seans 20 sn icinde
            # cikmadiysa milisaniye onemini yitirir, o yuzden yavaslatiyoruz.
            # Site Cloudflare arkasinda --- dakikalarca tam hizda yoklamak
            # hiz siniri yiyebilir.
            since_open = self.clock.now() - release_epoch
            interval = poll if since_open < 20 else (1.5 if since_open < 60 else 3.0)

            elapsed = time.time() - cycle_started
            if elapsed < interval:
                time.sleep(interval - elapsed)

        raise SlotNotReleased(
            f"{date_text} {time_text} seansı {give_up_after:.0f} sn içinde "
            f"yayınlanmadı ({attempts} yoklama). Seans başkası tarafından "
            f"kapılmış ya da bu saatte hiç açılmamış olabilir.")

    # ------------------------------------------------------------------
    # Rezervasyon
    # ------------------------------------------------------------------

    def confirm_reservation_modal(self, timeout: float = 10.0) -> bool:
        """Rezervasyon onay penceresindeki 'Tamam'a basar.

        Onemli: arama yalnizca modal kapsaminda yapiliyor. Eski kodun kullandigi
        `//button[contains(.,'Tamam')]` sayfa altindaki cerez bandindaki Tamam
        butonuyla da eslesiyordu ve yanlis butona basma riski vardi.
        """
        modal_scope = (
            "//*[contains(@class,'modal') or contains(@class,'swal2-') "
            "or @role='dialog'][not(contains(@style,'display: none'))]"
            "//button[contains(normalize-space(),'Tamam')"
            " or contains(normalize-space(),'Onayla')"
            " or contains(normalize-space(),'Evet')]")

        end = time.time() + timeout
        while time.time() < end:
            self._check_stop()
            for btn in self.driver.find_elements(By.XPATH, modal_scope):
                if btn.is_displayed():
                    self._js_click(btn)
                    self.log("Onay penceresi kabul edildi.")
                    return True
            time.sleep(0.15)

        # Modal cikmamis olabilir --- bazi seanslarda dogrudan rezervasyon
        # formuna dusuluyor. Form geldiyse sorun yok.
        if self._find(By.ID, "select2-ddlSatisTuru-container") is not None:
            self.log("Onay penceresi çıkmadı, doğrudan forma geçildi.")
            return False
        raise TimeoutException("Rezervasyon onay penceresi bulunamadı.")

    def choose_satis_turu(self, satis_turu: str) -> None:
        self.wait.until(EC.element_to_be_clickable(
            (By.ID, "select2-ddlSatisTuru-container")))
        self._select_dropdown("ddlSatisTuru", satis_turu)
        self.log(f"Satış türü seçildi: {satis_turu}")

    def add_to_cart(self) -> None:
        btn = self.wait.until(EC.presence_of_element_located(
            (By.ID, "pageContent_lbtnSepeteEkle")))
        self._scroll_to(btn)
        dismiss_overlays(self.driver)
        self._js_click(btn)
        self.log("Sepete eklendi.")

    # ------------------------------------------------------------------
    # SMS dogrulama
    # ------------------------------------------------------------------

    def await_otp_field(self, timeout: float = 30.0):
        field = WebDriverWait(self.driver, timeout).until(
            EC.presence_of_element_located((By.ID, "pageContent_txtDogrulamaKodu")))
        self._scroll_to(field, -150)
        return field

    def submit_otp(self, code: str) -> None:
        field = self.driver.find_element(By.ID, "pageContent_txtDogrulamaKodu")
        field.clear()
        field.send_keys(code)

        confirm = self._find(
            By.XPATH, "//*[self::a or self::button or self::input]"
                      "[contains(normalize-space(.),'Kodu Doğrula')"
                      " or contains(normalize-space(.),'Kodunu Doğrula')"
                      " or contains(@id,'DogrulamaKodu') and contains(@id,'lbtn')]")
        if confirm is None:
            raise RuntimeError("'Kodu Doğrula' butonu bulunamadı.")
        self._js_click(confirm)
        self.log("Doğrulama kodu gönderildi.")
