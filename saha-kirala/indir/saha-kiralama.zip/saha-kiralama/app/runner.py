"""Kiralama isini arka planda yuruten durum makinesi.

Selenium akisi bloklayici oldugu icin ayri bir thread'de calisiyor; arayuz
`snapshot()` ile durumu yokluyor. Tarayici is bitse de hata da alsa acik
kaliyor --- otomasyon bir yerde takilirsa kullanici devrali p elle bitirebilsin.
"""

from __future__ import annotations

import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

from selenium.common.exceptions import TimeoutException

from .browser import build_driver
from .models import BookingRequest
from .otp import OtpBroker
from .spor import SporIstanbul
from .timesync import Clock

# Kullanicinin ne oldugunu anlamasi icin durum etiketleri.
IDLE = "idle"
RUNNING = "running"
WAITING_OPEN = "waiting_open"
SNIPING = "sniping"
AWAITING_OTP = "awaiting_otp"
DONE = "done"
FAILED = "failed"
CANCELLED = "cancelled"

# Arayüzdeki ilerleme çubuğu. Kullanıcı akışın neresinde olduğunu görsün diye
# durumdan ayrı tutuluyor: "çalışıyor" tek başına hangi adımda olduğunu söylemez.
STEPS = [
    ("giris", "Giriş"),
    ("filtre", "Filtreler"),
    ("hazirlik", "Hazırlık"),
    ("bekleme", "Açılış"),
    ("yakalama", "Yakalama"),
    ("sepet", "Sepet"),
    ("sms", "SMS"),
]


class OtpTimeout(Exception):
    """SMS kodu zamaninda gelmedi."""


# Selenium istisnalari 30 satirlik chromedriver yigin izi tasiyor. Bunu oldugu
# gibi arayuze basmak kullaniciya hicbir sey anlatmiyor, sadece paniklatiyor.
# Taniyabildigimiz hatalari Turkce aciklamaya cevirip gerisini kirpiyoruz.
BILINEN_HATALAR = [
    ("timed out receiving message from renderer",
     "Chrome yanıt vermedi. Bu, Chrome'un ara sıra takılmasından kaynaklanan "
     "geçici bir arıza — tekrar deneyin."),
    ("no such window",
     "Tarayıcı penceresi kapanmış. Yeniden başlatın."),
    ("chrome not reachable",
     "Chrome'a ulaşılamıyor. Açık Chrome pencerelerini kapatıp tekrar deneyin."),
    ("session not created",
     "Chrome sürücüsü başlatılamadı. Chrome güncel mi kontrol edip tekrar deneyin."),
    ("err_internet_disconnected",
     "İnternet bağlantısı yok."),
    ("err_name_not_resolved",
     "Siteye ulaşılamıyor. İnternet bağlantınızı kontrol edin."),
]


def temiz_hata(exc: Exception) -> str:
    """Kullanıcıya gösterilebilir tek cümlelik hata metni."""
    ham = str(exc) or exc.__class__.__name__
    dusuk = ham.lower()

    for anahtar, aciklama in BILINEN_HATALAR:
        if anahtar in dusuk:
            return aciklama

    # Tanimadigimiz Selenium hatasi: yigin izini ve oturum bilgisini at.
    metin = ham.split("Stacktrace:")[0].split("(Session info:")[0]
    satirlar = [s.strip() for s in metin.replace("Message:", "").strip().splitlines()
                if s.strip()]

    if not satirlar:
        # Ciplak TimeoutException'in mesaji bostur. Yigin izini basmak yerine
        # ne olduğunu anlatiyoruz --- eskiden burada 20 satirlik chromedriver
        # ciktisi ekrana dusuyordu.
        if isinstance(exc, TimeoutException):
            return ("Sayfada beklenen öğe zamanında görünmedi. Site yavaş olabilir "
                    "ya da sayfa yapısı değişmiş olabilir.")
        return f"Beklenmeyen hata ({exc.__class__.__name__})."

    ilk = satirlar[0]
    return (ilk[:200] + "…") if len(ilk) > 200 else ilk


class BookingRunner:
    def __init__(self, broker: OtpBroker):
        self.broker = broker
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._driver = None
        self.reset()

    # ------------------------------------------------------------------

    def reset(self) -> None:
        with self._lock:
            self.status = IDLE
            self.step: str | None = None
            self.logs: list[dict] = []
            self.error: str | None = None
            self.request_summary: dict | None = None
            self.release_at: str | None = None
            self.clock_offset = 0.0

    def log(self, message: str) -> None:
        entry = {"t": datetime.now().strftime("%H:%M:%S.%f")[:-3], "m": message}
        with self._lock:
            self.logs.append(entry)
            del self.logs[:-400]
        print(f"[{entry['t']}] {message}", flush=True)

    def clear_logs(self) -> None:
        """Kaydı sunucu tarafında siler.

        Yalnızca arayüzü silmek yetmiyordu: bir sonraki durum yoklaması
        sunucudaki listeyi olduğu gibi geri yazıyordu.
        """
        with self._lock:
            self.logs.clear()

    def _set(self, status: str, step: str | None = None) -> None:
        with self._lock:
            self.status = status
            if step is not None:
                self.step = step

    def snapshot(self) -> dict:
        with self._lock:
            return {
                "status": self.status,
                "step": self.step,
                "steps": [{"id": i, "label": l} for i, l in STEPS],
                "logs": list(self.logs),
                "error": self.error,
                "request": self.request_summary,
                "release_at": self.release_at,
                "clock_offset": round(self.clock_offset, 3),
                "browser_open": self._driver is not None,
            }

    def is_busy(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    # ------------------------------------------------------------------

    def start(self, req: BookingRequest) -> None:
        if self.is_busy():
            raise RuntimeError("Zaten çalışan bir iş var.")
        self.close_browser()
        self.reset()
        self._stop.clear()

        with self._lock:
            self.request_summary = req.redacted()
            self.release_at = req.release_at().strftime("%d.%m.%Y %H:%M:%S")

        self._thread = threading.Thread(target=self._run, args=(req,), daemon=True)
        self._thread.start()

    def cancel(self) -> None:
        self._stop.set()
        self.log("İptal istendi.")

    def submit_otp(self, code: str) -> None:
        self.broker.submit_manual(code)
        self.log("Kod arayüzden alındı.")

    def _hata_kaydi_al(self) -> None:
        """Hata anında ekran görüntüsü + sayfa HTML'i kaydeder.

        Bir aksaklığın nedenini uzaktan anlamak, ekranda tek satır hata
        mesajıyla neredeyse imkânsız. Bunlar teşhis için; kimlik bilgisi
        içermez (şifre alanı DOM'da değeri tutmaz).
        """
        driver = self._driver
        if driver is None:
            return
        try:
            klasor = Path.home() / ".saha-kiralama" / "hatalar"
            klasor.mkdir(parents=True, exist_ok=True)
            damga = datetime.now().strftime("%Y%m%d-%H%M%S")

            driver.save_screenshot(str(klasor / f"{damga}.png"))
            (klasor / f"{damga}.html").write_text(
                driver.page_source, encoding="utf-8", errors="replace")
            (klasor / f"{damga}.txt").write_text(
                f"URL   : {driver.current_url}\n"
                f"Başlık: {driver.title}\n"
                f"Adım  : {self.step}\n"
                f"Hata  : {self.error}\n",
                encoding="utf-8")

            self.log(f"Teşhis dosyaları kaydedildi: {klasor}\\{damga}.*")
        except Exception:
            pass   # teşhis kaydı alınamadıysa asıl hatayı gölgelemesin

    def close_browser(self) -> None:
        driver, self._driver = self._driver, None
        if driver is not None:
            try:
                driver.quit()
            except Exception:
                pass

    # ------------------------------------------------------------------

    def _run(self, req: BookingRequest) -> None:
        stop = self._stop.is_set
        try:
            self._set(RUNNING)

            # Saat olcumu spor.istanbul'a birkac istek atiyor ve saniyeler
            # surebiliyor. Tarayiciyi bunun icin bekletmeye gerek yok --- ikisi
            # ayni anda ilerlesin, tarayici hemen acilsin.
            olcum: dict = {}
            olcucu = threading.Thread(
                target=lambda: olcum.setdefault("clock", Clock.synced()), daemon=True)
            olcucu.start()

            self._set(RUNNING, "giris")
            self.log("Tarayıcı açılıyor...")
            self._driver = build_driver(headless=req.headless)

            olcucu.join(timeout=12)
            clock = olcum.get("clock") or Clock(None)
            with self._lock:
                self.clock_offset = clock.offset
            if clock.verified:
                yon = "ileri" if clock.offset < 0 else "geri"
                self.log(f"Bu bilgisayarın saati sunucudan {abs(clock.offset):.1f} sn "
                         f"{yon}. Bekleme sunucu saatine göre yapılacak.")
            else:
                self.log("UYARI: Sunucu saati ölçülemedi, bu bilgisayarın saati "
                         "kullanılacak. Saat kaymışsa yoklama yanlış anda "
                         "başlayabilir — Windows'ta 'w32tm /resync /force' ile "
                         "saati eşitleyip tekrar deneyin.")

            site = SporIstanbul(self._driver, log=self.log, stop=stop, clock=clock)

            site.login(req.tc, req.password)
            self._set(RUNNING, "filtre")
            site.open_search_page()
            site.select_filters(req.brans, req.tesis, req.salon)

            # Acilis oncesi sonuc sayfasina inip hazir bekliyoruz.
            self._set(RUNNING, "hazirlik")
            self.log("Sonuç sayfası hazırlanıyor...")
            site.fire_search()
            site.verify_results_page()
            site.warm_up()

            release_epoch = req.release_at().timestamp()
            beklemede = clock.now() < release_epoch - req.lead_seconds
            self._set(WAITING_OPEN if beklemede else SNIPING,
                      "bekleme" if beklemede else "yakalama")

            site.snipe(req.date_text, req.time_text, release_epoch,
                       lead=req.lead_seconds, poll=req.poll_interval,
                       give_up_after=req.give_up_after,
                       on_poll_start=lambda: self._set(SNIPING, "yakalama"))
            self._set(RUNNING, "sepet")

            site.confirm_reservation_modal()
            site.show_reservation_panel()

            if req.stop_before_cart:
                self.log("Kuru test: sepete ekleme adımı atlandı.")
                self._set(DONE)
                return

            site.choose_satis_turu(req.satis_turu)
            site.add_to_cart()

            # SMS bu andan sonra gelecek; daha eski mesajlari kod sanmayalim.
            sms_window_start = time.time() - 5
            site.await_otp_field()
            self._set(AWAITING_OTP, "sms")
            self.log("SMS kodu bekleniyor (otomatik kaynaklar + elle giriş).")

            code = self.broker.wait_for_code(
                sms_window_start, timeout=180, requested=req.otp_provider,
                stop=stop, log=self.log)
            if code is None:
                raise OtpTimeout("SMS kodu alınamadı (3 dk). Tarayıcı açık "
                                 "bırakıldı, elle tamamlayabilirsiniz.")

            site.submit_otp(code)
            self.log("Rezervasyon tamamlandı. Sepeti kontrol edin.")
            self._set(DONE)

        except Exception as exc:
            if self._stop.is_set():
                self._set(CANCELLED)
                self.log("İş iptal edildi. Tarayıcı açık bırakıldı.")
                return
            with self._lock:
                self.error = temiz_hata(exc)
            self._set(FAILED)
            self.log(f"HATA: {self.error}")
            self._hata_kaydi_al()
            self.log("Tarayıcı açık bırakıldı, elle devam edebilirsiniz.")
            traceback.print_exc()
