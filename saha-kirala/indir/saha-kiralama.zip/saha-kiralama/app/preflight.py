"""Bu bilgisayarda otomasyon çalışabilir mi?

Arayüzdeki "Sistem kontrolü" paneli bunu kullanır. Amaç, kullanıcının işi
başlatmadan önce eksiği görmesi — açılış anında sürpriz yaşamak yerine.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys

CHROME_PATHS = {
    "Windows": [
        r"C:\Program Files\Google\Chrome\Application\chrome.exe",
        r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
        os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    ],
    "Darwin": [
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        os.path.expanduser(
            "~/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
    ],
    "Linux": [],
}

CHROME_HINT = {
    "Windows": "Chrome'u google.com/chrome adresinden kurun.",
    "Darwin": "Chrome'u google.com/chrome adresinden kurun.",
    "Linux": "google-chrome ya da chromium paketini kurun.",
}


def _ok(name, ok, note, hint=None, critical=True):
    return {"name": name, "ok": ok, "note": note, "hint": hint, "critical": critical}


def find_chrome() -> str | None:
    system = platform.system()
    for path in CHROME_PATHS.get(system, []):
        if os.path.exists(path):
            return path
    for exe in ("google-chrome", "chrome", "chromium", "chromium-browser"):
        found = shutil.which(exe)
        if found:
            return found
    return None


def chrome_version(path: str) -> str | None:
    """Chrome sürümünü okur. Windows'ta --version çalışmadığı için ayrı yol."""
    if platform.system() == "Windows":
        try:
            out = subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 f"(Get-Item '{path}').VersionInfo.ProductVersion"],
                capture_output=True, text=True, timeout=15).stdout.strip()
            return out or None
        except Exception:
            return None
    try:
        return subprocess.run([path, "--version"], capture_output=True,
                              text=True, timeout=15).stdout.strip() or None
    except Exception:
        return None


def run_checks() -> dict:
    checks = []
    system = platform.system()
    friendly = {"Windows": "Windows", "Darwin": "macOS"}.get(system, system)

    # --- Python -----------------------------------------------------------
    version = sys.version_info
    checks.append(_ok(
        "Python",
        version >= (3, 10),
        f"{version.major}.{version.minor}.{version.micro} — {friendly}",
        "Python 3.10 veya üstü gerekiyor: python.org/downloads"))

    # --- Bağımlılıklar ----------------------------------------------------
    missing = []
    for module in ("selenium", "fastapi", "uvicorn", "requests"):
        try:
            __import__(module)
        except ImportError:
            missing.append(module)
    checks.append(_ok(
        "Python paketleri",
        not missing,
        "hepsi kurulu" if not missing else "eksik: " + ", ".join(missing),
        "pip install -r requirements.txt"))

    # --- Chrome -----------------------------------------------------------
    chrome = find_chrome()
    checks.append(_ok(
        "Google Chrome",
        bool(chrome),
        (chrome_version(chrome) or chrome) if chrome else "bulunamadı",
        CHROME_HINT.get(system, "Chrome kurun.")))

    # --- Sürücü -----------------------------------------------------------
    # Selenium 4.6+ chromedriver'ı kendi indirir; ayrıca kurulum gerekmez.
    try:
        import selenium
        sel_ok = tuple(int(p) for p in selenium.__version__.split(".")[:2]) >= (4, 6)
        sel_note = (f"Selenium {selenium.__version__} — sürücüyü kendi indirir"
                    if sel_ok else f"Selenium {selenium.__version__} çok eski")
    except Exception as exc:
        sel_ok, sel_note = False, str(exc)
    checks.append(_ok("Chrome sürücüsü", sel_ok, sel_note,
                      "pip install -U selenium"))

    # --- Siteye erişim ----------------------------------------------------
    try:
        import requests
        from .timesync import measure_offset
        resp = requests.head("https://online.spor.istanbul/", timeout=8,
                             allow_redirects=True)
        offset = measure_offset()
        checks.append(_ok("Siteye erişim", resp.status_code < 500,
                          f"HTTP {resp.status_code}", "İnternet bağlantınızı kontrol edin."))
        if offset is None:
            checks.append(_ok(
                "Saat farkı", False, "ölçülemedi — bu bilgisayarın saati kullanılacak",
                "Saatiniz kaymışsa yoklama yanlış anda başlar. "
                "Windows: w32tm /resync /force", critical=False))
        else:
            yon = "ileri" if offset < 0 else "geri"
            checks.append(_ok(
                "Saat farkı", abs(offset) < 120,
                f"bilgisayar sunucudan {abs(offset):.1f} sn {yon} — otomatik telafi ediliyor",
                None, critical=False))
    except Exception as exc:
        checks.append(_ok("Siteye erişim", False, f"ulaşılamadı: {exc}",
                          "İnternet bağlantınızı kontrol edin."))

    critical_failures = [c for c in checks if c["critical"] and not c["ok"]]
    return {
        "platform": friendly,
        "ready": not critical_failures,
        "checks": checks,
    }
