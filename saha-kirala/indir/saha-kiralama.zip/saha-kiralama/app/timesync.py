"""Sunucu saatiyle yerel saat arasindaki farki olcer.

Seanslar sunucu saatine gore aciliyor. Windows saati birkac saniye sapabildigi
icin hedef ani yerel saatle beklemek riskli; onun yerine sunucunun HTTP `Date`
header'ini referans aliyoruz.

`Date` header'i saniye hassasiyetinde. Sub-saniye dogruluk icin header degerinin
degistigi ani yakaliyoruz: degisimi gordugumuz yerel zaman, sunucudaki saniye
sinirina denk gelir (~+/- bir poll araligi kadar hata payiyla).
"""

from __future__ import annotations

import time
from email.utils import parsedate_to_datetime

import requests

PROBE_URL = "https://online.spor.istanbul/"

# Hedef sitenin `Date` başlığı bazen alınamıyor (geçici ağ hatası ya da çok
# sık isteğe karşı hız sınırı). Bu durumda ölçümü sessizce atlayıp bozuk yerel
# saate dönmek en kötüsü olur --- düzeltmeye çalıştığımız sorunun ta kendisi.
# Ölçüm sırasında üç bağımsız sunucunun saatinin saniyesi saniyesine uyuştuğu
# doğrulandı, o yüzden yedek olarak başkalarını kullanmak güvenli.
FALLBACK_URLS = ["https://www.google.com/", "https://www.cloudflare.com/"]


def _server_epoch(session: requests.Session, url: str) -> tuple[float, float]:
    """(sunucu_epoch, yanitin_alindigi_yerel_epoch) dondurur."""
    resp = session.head(url, timeout=5, allow_redirects=True)
    local = time.time()
    date_header = resp.headers.get("Date")
    if not date_header:
        raise RuntimeError("Sunucu 'Date' header'i dondurmedi.")
    return parsedate_to_datetime(date_header).timestamp(), local


def _measure_one(session: requests.Session, url: str, max_seconds: float) -> float:
    base_server, _ = _server_epoch(session, url)
    deadline = time.time() + max_seconds

    # Header'in bir sonraki saniyeye gectigi ani yakala.
    while time.time() < deadline:
        server, local = _server_epoch(session, url)
        if server > base_server:
            # `server` az once basladi; yani sunucuda tam o saniyenin basi.
            return server - local
        time.sleep(0.15)

    # Gecis yakalanamadi: kaba olcum. Header saniyenin herhangi bir aninda
    # uretilmis olabilir, ortalama 0.5 sn hata payi ekliyoruz.
    server, local = _server_epoch(session, url)
    return (server + 0.5) - local


def measure_offset(url: str = PROBE_URL, max_seconds: float = 3.0) -> float | None:
    """offset = sunucu_saati - yerel_saat (saniye).

    Pozitif değer yerel saatin geride olduğunu gösterir. Hedef site
    ulaşılamazsa yedek sunucular denenir. Hiçbiri olmazsa **None** döner ---
    çağıran taraf bunu sessizce 0 saymamalı, kullanıcıyı uyarmalı.
    """
    session = requests.Session()
    try:
        for candidate in [url, *FALLBACK_URLS]:
            try:
                return _measure_one(session, candidate, max_seconds)
            except Exception:
                continue
        return None
    finally:
        session.close()


class Clock:
    """Sunucu saatine hizalanmış saat.

    `verified` False ise fark ölçülemedi ve yerel saat olduğu gibi kullanılıyor
    demektir. Bu durumda zamanlama garantisi yoktur; çağıran taraf uyarmalı.
    """

    def __init__(self, offset: float | None = 0.0):
        self.verified = offset is not None
        self.offset = offset or 0.0

    @classmethod
    def synced(cls, url: str = PROBE_URL) -> "Clock":
        return cls(measure_offset(url))

    def now(self) -> float:
        """Sunucu saatine gore simdiki epoch."""
        return time.time() + self.offset

    def sleep_until(self, target_epoch: float, stop=None) -> None:
        """Sunucu saatine gore hedef ana kadar bekler.

        `stop` verilirse, callable her dongude kontrol edilir ve True donerse
        bekleme erken biter.
        """
        while True:
            remaining = target_epoch - self.now()
            if remaining <= 0:
                return
            if stop is not None and stop():
                return
            time.sleep(min(remaining, 0.05))
