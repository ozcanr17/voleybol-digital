"""SMS dogrulama kodunu yakalama.

Uc otomatik kaynak + her zaman acik manuel giris var. Hepsi ayni anda dinlenir,
ilk gelen kod kazanir. Yani otomatik kaynak calismazsa kullanici koda elle
girdiginde akis kaldigi yerden devam eder.

  adb      Android telefon USB ile bagli ve "USB hata ayiklama" acik. Telefona
           hicbir uygulama kurmak gerekmez. Windows'ta da macOS'ta da calisir.
  macos    macOS + Messages'a SMS yonlendirme acik (iPhone "Metin Mesaji
           Yonlendirme"). chat.db'yi okur; Terminal'e Tam Disk Erisimi gerekir.
  webhook  Telefondaki herhangi bir SMS yonlendirme uygulamasi POST /api/sms
           adresine mesaji birakir. Telegram vb. gerekmez, sadece yerel ag.
  manual   Kullanici kodu arayuze yazar. Digerleri yoksa/basarisizsa devreye
           girer, ama aslinda her zaman aktiftir.
"""

from __future__ import annotations

import os
import platform
import queue
import re
import shutil
import sqlite3
import subprocess
import threading
import time

# 4-8 haneli kodu yakala. Cok kisa/uzun sayilari (tarih, tutar) eleriz.
CODE_RE = re.compile(r"(?<!\d)(\d{4,8})(?!\d)")

# Mesajin gercekten bu siteden geldigini gosteren ipuclari. Bilerek dar
# tutuldu: "kod" ya da "onay" gibi genel kelimeler kargo/banka SMS'lerinde de
# gectigi icin yanlis kod gonderme riski yaratiyor. Yanlis kod gondermek
# denemenin bosa gitmesine yol acar; kacirmak ise sadece elle girise duser.
# Gercek SMS metnini gordukten sonra buraya kendi ipucunuzu ekleyebilirsiniz.
HINT_RE = re.compile(r"spor\s*istanbul|spor\.istanbul|ibb|do[gğ]rulama|rezervasyon|seans", re.I)

APPLE_EPOCH_OFFSET = 978_307_200  # 2001-01-01 ile 1970-01-01 arasi saniye


def extract_code(text: str) -> str | None:
    """Mesaj govdesinden dogrulama kodunu cikarir.

    Ipucu kelimesi ("dogrulama", "spor", "kod"...) gecmeyen mesajlari eliyoruz.
    Aksi halde bekleme penceresinde gelen alakasiz bir SMS --- "Toplam 1500,00
    TL" gibi --- kod sanilip gonderilebiliyor. Yanlis kod gondermektense
    kullanicidan elle girmesini beklemek daha iyi.
    """
    if not text or not HINT_RE.search(text):
        return None
    matches = CODE_RE.findall(text)
    return matches[0] if matches else None


# --------------------------------------------------------------------------
# Kaynaklar
# --------------------------------------------------------------------------

class SmsSource:
    """Belirli bir andan sonra gelen SMS govdelerini dondurur."""

    name = "base"

    def available(self) -> tuple[bool, str]:
        """(kullanilabilir_mi, aciklama)"""
        raise NotImplementedError

    def messages_since(self, since_epoch: float) -> list[str]:
        raise NotImplementedError


class AdbSource(SmsSource):
    name = "adb"

    def __init__(self, adb_path: str | None = None):
        self.adb = adb_path or shutil.which("adb") or ""

    def available(self) -> tuple[bool, str]:
        if not self.adb:
            return False, "adb bulunamadı (Android Platform Tools kurulu değil)."
        try:
            out = subprocess.run([self.adb, "devices"], capture_output=True,
                                 text=True, timeout=10).stdout
        except Exception as exc:
            return False, f"adb çalıştırılamadı: {exc}"
        devices = [ln for ln in out.splitlines()[1:] if ln.strip().endswith("device")]
        if not devices:
            return False, "USB ile bağlı, hata ayıklaması açık bir cihaz yok."
        # SMS okuma izni gercekten var mi, bir kez dene.
        try:
            probe = subprocess.run(
                [self.adb, "shell", "content", "query", "--uri",
                 "content://sms/inbox", "--projection", "date", "--sort",
                 "date DESC LIMIT 1"],
                capture_output=True, text=True, timeout=10)
        except Exception as exc:
            return False, f"SMS sorgusu başarısız: {exc}"
        if "Permission Denial" in (probe.stdout + probe.stderr):
            return False, "Cihaz adb'ye SMS okuma izni vermiyor."
        return True, "Android cihaz bağlandı."

    def messages_since(self, since_epoch: float) -> list[str]:
        # Projeksiyonda `body`yi sona koyuyoruz: govdedeki virguller ayristirmayi
        # bozmasin diye.
        try:
            out = subprocess.run(
                [self.adb, "shell", "content", "query", "--uri",
                 "content://sms/inbox", "--projection", "date:body", "--sort",
                 "date DESC LIMIT 10"],
                capture_output=True, text=True, timeout=10).stdout
        except Exception:
            return []

        found = []
        for line in out.splitlines():
            if "date=" not in line or "body=" not in line:
                continue
            try:
                ts_part = line.split("date=", 1)[1].split(",", 1)[0].strip()
                sms_epoch = int(ts_part) / 1000.0
            except (ValueError, IndexError):
                continue
            if sms_epoch < since_epoch:
                continue
            found.append(line.split("body=", 1)[1].strip())
        return found


class MacMessagesSource(SmsSource):
    name = "macos"

    DB = os.path.expanduser("~/Library/Messages/chat.db")

    def available(self) -> tuple[bool, str]:
        if platform.system() != "Darwin":
            return False, "Sadece macOS'ta çalışır."
        if not os.path.exists(self.DB):
            return False, "Mesajlar veritabanı bulunamadı."
        try:
            self._query(time.time())
        except sqlite3.OperationalError:
            return False, ("chat.db okunamıyor. Sistem Ayarları > Gizlilik ve "
                           "Güvenlik > Tam Disk Erişimi'nde Terminal'e izin verin.")
        return True, "Mesajlar veritabanı okunabiliyor."

    def _query(self, since_epoch: float) -> list[str]:
        apple_ts = int((since_epoch - APPLE_EPOCH_OFFSET) * 1_000_000_000)
        conn = sqlite3.connect(f"file:{self.DB}?mode=ro", uri=True, timeout=5)
        try:
            rows = conn.execute(
                "SELECT text FROM message WHERE date > ? AND text IS NOT NULL "
                "ORDER BY date DESC LIMIT 10", (apple_ts,)).fetchall()
        finally:
            conn.close()
        return [r[0] for r in rows]

    def messages_since(self, since_epoch: float) -> list[str]:
        try:
            return self._query(since_epoch)
        except Exception:
            return []


class WebhookSource(SmsSource):
    """Telefondaki yonlendirme uygulamasinin POST ettigi mesajlar."""

    name = "webhook"

    def __init__(self):
        self._inbox: list[tuple[float, str]] = []
        self._lock = threading.Lock()

    def available(self) -> tuple[bool, str]:
        return True, "POST /api/sms adresi dinleniyor."

    def push(self, text: str) -> None:
        with self._lock:
            self._inbox.append((time.time(), text))
            del self._inbox[:-50]

    def messages_since(self, since_epoch: float) -> list[str]:
        with self._lock:
            return [t for ts, t in self._inbox if ts >= since_epoch]


# --------------------------------------------------------------------------
# Broker
# --------------------------------------------------------------------------

class OtpBroker:
    """Tum kaynaklari paralel dinler, ilk gecerli kodu dondurur."""

    def __init__(self):
        self.webhook = WebhookSource()
        self._sources: dict[str, SmsSource] = {
            "adb": AdbSource(),
            "macos": MacMessagesSource(),
            "webhook": self.webhook,
        }
        self._manual: queue.Queue[str] = queue.Queue()

    def submit_manual(self, code: str) -> None:
        """Arayuzden elle girilen kod."""
        self._manual.put(code.strip())

    def probe(self) -> list[dict]:
        """Hangi kaynaklarin hazir oldugunu raporlar (arayuzde gosterilir)."""
        report = []
        for name, src in self._sources.items():
            ok, note = src.available()
            report.append({"name": name, "ready": ok, "note": note})
        return report

    def active_sources(self, requested: str) -> list[SmsSource]:
        if requested in self._sources:
            src = self._sources[requested]
            return [src] if src.available()[0] else []
        if requested == "manual":
            return []
        # auto: hazir olan her seyi dinle
        return [s for s in self._sources.values() if s.available()[0]]

    def wait_for_code(self, since_epoch: float, timeout: float,
                      requested: str = "auto", stop=None, log=None) -> str | None:
        """Kod gelene kadar bekler. Manuel giris her zaman dinlenir."""
        # Bekleme sirasinda bayat manuel girisler kalmasin.
        while not self._manual.empty():
            self._manual.get_nowait()

        sources = self.active_sources(requested)
        deadline = time.time() + timeout
        seen: set[str] = set()

        while time.time() < deadline:
            if stop is not None and stop():
                return None

            try:
                return self._manual.get(timeout=0.5)
            except queue.Empty:
                pass

            for src in sources:
                for body in src.messages_since(since_epoch):
                    code = extract_code(body)
                    if code:
                        if log:
                            log(f"Kod {src.name} kaynağından alındı.")
                        return code
                    # Elenen mesaji bir kez bildir: gercek SMS metni beklenen
                    # ipucunu icermiyorsa kullanici bunu gorup ayarlayabilsin.
                    if log and body not in seen:
                        seen.add(body)
                        log(f"[{src.name}] SMS elendi (ipucu eşleşmedi): "
                            f"{body[:60]!r}")
        return None
