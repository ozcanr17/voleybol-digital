"""Yerel web arayuzu.

Sunucu yalnizca bu bilgisayarda calisir. Kimlik bilgileri hicbir yere
kaydedilmez --- forma girilir, bellekte tutulur, is bitince gider.
"""

from __future__ import annotations

import os
from pathlib import Path

from fastapi import Body, FastAPI, HTTPException, Response
from fastapi.responses import FileResponse, JSONResponse
from pydantic import ValidationError

from .models import BookingRequest
from .otp import OtpBroker
from .preflight import run_checks
from .runner import BookingRunner

STATIC = Path(__file__).parent / "static"

app = FastAPI(title="Saha Kiralama")
broker = OtpBroker()
runner = BookingRunner(broker)

# --------------------------------------------------------------------------
# voleybol.digital/saha-kirala sayfasının "kurulu mu?" kontrolü
# --------------------------------------------------------------------------
# Statik sayfa bu adrese istek atıp cevap alırsa uygulamanın kurulu ve çalışır
# olduğunu anlar. Tarayıcı bir web sayfasının bilgisayarı incelemesine izin
# vermez; tek meşru yol budur.
#
# İzin BİLEREK dar: yalnızca bilinen kaynaklar, yalnızca durum okuyan iki uç.
# İşi başlatan/iptal eden uçlar dışarıdan çağrılamaz --- aksi halde ziyaret
# edilen herhangi bir kötü niyetli sayfa buradaki otomasyonu sürebilirdi.
ALLOWED_ORIGINS = {
    "https://voleybol.digital",
    "https://www.voleybol.digital",
    "https://ozcanr17.github.io",
}
# Sayfayı başka bir adreste denemek için: SAHA_EXTRA_ORIGINS="http://localhost:5500"
ALLOWED_ORIGINS |= {
    o.strip() for o in os.environ.get("SAHA_EXTRA_ORIGINS", "").split(",") if o.strip()
}
PUBLIC_PATHS = {"/api/onkontrol", "/api/status"}


@app.middleware("http")
async def kisitli_cors(request, call_next):
    origin = request.headers.get("origin")
    izinli = origin in ALLOWED_ORIGINS and request.url.path in PUBLIC_PATHS

    if request.method == "OPTIONS" and izinli:
        # Chrome, genel ağdan yerel ağa yapılan isteklerde ayrıca bu izni ister
        # (Private Network Access).
        return Response(status_code=200, headers={
            "Access-Control-Allow-Origin": origin,
            "Access-Control-Allow-Methods": "GET, OPTIONS",
            "Access-Control-Allow-Private-Network": "true",
            "Access-Control-Max-Age": "600",
        })

    response = await call_next(request)
    if izinli:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Private-Network"] = "true"
    return response


@app.get("/")
def index():
    # Önbelleğe ALINMASIN. Uygulama güncellendiğinde tarayıcı eski arayüzü
    # sunmaya devam ediyordu: düzeltilmiş butonlar çalışmıyor, giderilmiş
    # hatalar geri geliyor gibi görünüyordu.
    return FileResponse(STATIC / "index.html", headers={
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Pragma": "no-cache",
        "Expires": "0",
    })


@app.get("/api/status")
def status():
    return runner.snapshot()


@app.get("/api/onkontrol")
def onkontrol():
    """Bu bilgisayarda otomasyon çalışabilir mi?"""
    return run_checks()


@app.get("/api/otp-sources")
def otp_sources():
    """Bu bilgisayarda hangi otomatik SMS kaynaklari hazir?"""
    return {"sources": broker.probe()}


@app.post("/api/start")
def start(payload: dict = Body(...)):
    try:
        req = BookingRequest(**payload)
    except ValidationError as exc:
        messages = [f"{e['loc'][0] if e['loc'] else 'alan'}: {e['msg']}"
                    for e in exc.errors()]
        raise HTTPException(422, detail="; ".join(messages))

    try:
        runner.start(req)
    except RuntimeError as exc:
        raise HTTPException(409, detail=str(exc))

    return {"ok": True, "release_at": runner.release_at}


@app.post("/api/clear-log")
def clear_log():
    runner.clear_logs()
    return {"ok": True}


@app.post("/api/cancel")
def cancel():
    runner.cancel()
    return {"ok": True}


@app.post("/api/otp")
def submit_otp(payload: dict = Body(...)):
    code = str(payload.get("code", "")).strip()
    if not code.isdigit():
        raise HTTPException(400, detail="Kod sadece rakam olmalı.")
    runner.submit_otp(code)
    return {"ok": True}


@app.post("/api/sms")
def receive_sms(payload: dict = Body(...)):
    """Telefondaki SMS yonlendirme uygulamasi buraya POST eder.

    Beklenen govde: {"text": "... kodunuz 123456 ..."}
    Yaygin uygulamalarin alan adlari da kabul ediliyor.
    """
    text = (payload.get("text") or payload.get("message")
            or payload.get("body") or payload.get("msg") or "")
    if not text:
        raise HTTPException(400, detail="Mesaj gövdesi boş.")
    broker.webhook.push(str(text))
    return {"ok": True}


@app.post("/api/close-browser")
def close_browser():
    runner.close_browser()
    return {"ok": True}


@app.exception_handler(Exception)
def unhandled(request, exc):
    return JSONResponse(status_code=500, content={"detail": str(exc)})
