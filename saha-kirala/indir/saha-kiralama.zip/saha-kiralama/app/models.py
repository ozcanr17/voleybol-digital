"""Arayuzden gelen kiralama talebinin modeli."""

from __future__ import annotations

import re
from datetime import datetime, timedelta

from pydantic import BaseModel, Field, field_validator

# Seanslar seans saatinden tam 72 saat once aciliyor.
RELEASE_LEAD = timedelta(hours=72)

TIME_RANGE_RE = re.compile(r"^\s*(\d{2}):(\d{2})\s*-\s*(\d{2}):(\d{2})\s*$")
DATE_RE = re.compile(r"^\s*(\d{2})\.(\d{2})\.(\d{4})\s*$")


class BookingRequest(BaseModel):
    # Kimlik --- diske hicbir zaman yazilmaz, sadece bellekte tutulur.
    tc: str = Field(min_length=11, max_length=11)
    password: str = Field(min_length=1)

    # Saha secimi
    brans: str = "KİRALAMA (BASKETBOL - VOLEYBOL)"
    tesis: str
    salon: str | None = None

    # Rezervasyon
    satis_turu: str = "Voleybol"
    date_text: str          # "29.07.2026"
    time_text: str          # "19:00 - 20:00"

    # Zamanlama --- bos birakilirsa seans saatinden 72 saat geri hesaplanir.
    open_at: datetime | None = None
    lead_seconds: float = 3.0        # hedeften kac sn once yoklamaya baslasin
    poll_interval: float = 0.4       # yoklamalar arasi bekleme
    give_up_after: float = 180.0     # acilis aninda kac sn deneyip vazgecsin

    # Davranis
    headless: bool = False
    otp_provider: str = "auto"       # auto | manual | adb | macos | webhook
    stop_before_cart: bool = False   # True: sepete eklemeden once dur (kuru test)

    @field_validator("tc")
    @classmethod
    def _tc_digits(cls, v: str) -> str:
        v = v.strip()
        if not v.isdigit():
            raise ValueError("T.C. Kimlik No sadece rakamlardan oluşmalı.")
        return v

    @field_validator("date_text")
    @classmethod
    def _date_format(cls, v: str) -> str:
        if not DATE_RE.match(v):
            raise ValueError("Tarih GG.AA.YYYY biçiminde olmalı (örn. 29.07.2026).")
        return v.strip()

    @field_validator("time_text")
    @classmethod
    def _time_format(cls, v: str) -> str:
        if not TIME_RANGE_RE.match(v):
            raise ValueError("Saat 'SS:DD - SS:DD' biçiminde olmalı (örn. 19:00 - 20:00).")
        return v.strip()

    @field_validator("salon")
    @classmethod
    def _blank_salon_is_none(cls, v: str | None) -> str | None:
        return v.strip() or None if v else None

    def slot_start(self) -> datetime:
        """Seansin baslangic tarihi/saati."""
        d = DATE_RE.match(self.date_text)
        t = TIME_RANGE_RE.match(self.time_text)
        assert d and t  # validator'lar garanti ediyor
        return datetime(int(d.group(3)), int(d.group(2)), int(d.group(1)),
                        int(t.group(1)), int(t.group(2)))

    def release_at(self) -> datetime:
        """Seansin acilacagi an (yerel takvim saati)."""
        return self.open_at or (self.slot_start() - RELEASE_LEAD)

    def redacted(self) -> dict:
        """Loglara/arayuze gonderilebilir hali."""
        data = self.model_dump(exclude={"tc", "password"})
        data["tc"] = f"{self.tc[:3]}****{self.tc[-2:]}"
        return data
