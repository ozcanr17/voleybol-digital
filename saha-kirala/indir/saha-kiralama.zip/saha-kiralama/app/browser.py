"""Chrome surucusu ve sayfa ustune binen katmanlarin (cerez, duyuru, anket)
temizlenmesi."""

from __future__ import annotations

import subprocess
import sys

from selenium import webdriver
from selenium.webdriver.chrome.options import Options


def build_driver(headless: bool = False, page_load_timeout: float = 30.0):
    options = Options()

    # `navigator.webdriver` bayragini ve "otomatik test yazilimi" bilgi cubugunu
    # kaldirir. Bunu tespit kacirmak icin degil, sitenin normal bir tarayiciya
    # davrandigi gibi davranmasi icin yapiyoruz.
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)

    # Chrome'un "Sifre kaydedilsin mi?" kutusu sayfanin ustune biniyor ve
    # kritik anda tiklamalari yiyebiliyor. Sifre yoneticisini tamamen kapat.
    options.add_experimental_option("prefs", {
        "credentials_enable_service": False,
        "profile.password_manager_enabled": False,
        "profile.password_manager_leak_detection": False,
        "autofill.profile_enabled": False,
        "autofill.credit_card_enabled": False,
    })
    options.add_argument("--disable-save-password-bubble")
    options.add_argument("--disable-features=PasswordLeakDetection,AutofillServerCommunication")

    # Python sureci bitse de tarayici acik kalsin --- otomasyon bir yerde
    # takilirsa kullanici devralip elle bitirebilsin diye. Orijinal script'te
    # de vardi, kaldirmakla hata etmisim.
    options.add_experimental_option("detach", True)

    if headless:
        options.add_argument("--headless=new")
        options.add_argument("--window-size=1920,1080")
    else:
        options.add_argument("--start-maximized")

    # Postback'ten sonra tum alt kaynaklarin yuklenmesini beklemeyelim; DOM
    # hazir oldugu anda kontrole gecmek kritik anda saniye kazandiriyor.
    options.page_load_strategy = "eager"

    # Site yerel `alert()` kutulari kullaniyor (orn. "Rezervasyon Islemi
    # Gerceklestiriyorsunuz"). Varsayilan davranis bunlari otomatik kapatip
    # komutu hataya dusuruyor. "ignore" ile kutu ayakta kaliyor; metnini okuyup
    # kullaniciya gosterdikten sonra biz kabul ediyoruz --- boylece site ne
    # dediyse kayitta gorunuyor.
    options.set_capability("unhandledPromptBehavior", "ignore")

    driver = webdriver.Chrome(options=options)
    driver.set_page_load_timeout(page_load_timeout)

    # Not: Onbellegi CDP ile kapatmayi denemistik, gereksizdi ve bir hareketli
    # parca daha demekti. Her calistirmada Chrome zaten sifir onbellekle yeni
    # bir gecici profil aciyor; tazeleme ise formu yeniden gonderme yoluyla.

    if not headless:
        # `--start-maximized` her zaman tutmuyor (ozellikle pencere daha once
        # kucuk birakilmissa). Aciktan buyutuyoruz.
        try:
            driver.maximize_window()
        except Exception:
            pass
        one_getir(driver)

    return driver


def one_getir(driver) -> bool:
    """Chrome penceresini one getirir (Windows).

    Selenium pencereyi acar ama odaklamaz; kullanicinin baktigi pencerenin
    arkasinda kalabiliyor. Windows, arka plandaki bir surecin odagi calmasini
    engelledigi icin once kendi is parcacigimizi on plandaki pencereye
    bagliyoruz --- SetForegroundWindow'un calismasinin standart yolu bu.

    Basarisiz olursa sessizce vazgecer: pencerenin arkada kalmasi can sikici
    ama otomasyonu durdurmaz.
    """
    if sys.platform != "win32":
        return False
    try:
        import ctypes
        from ctypes import wintypes

        u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32

        # chromedriver'in baslattigi chrome sureclerinin pencerelerini bul.
        surucu_pid = driver.service.process.pid
        hedefler = _alt_surec_pidleri(surucu_pid)
        if not hedefler:
            return False

        bulunan = []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def geri_cagir(hwnd, _):
            if not u32.IsWindowVisible(hwnd):
                return True
            pid = wintypes.DWORD()
            u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value in hedefler and u32.GetWindow(hwnd, 4) == 0:  # GW_OWNER
                bulunan.append(hwnd)
            return True

        u32.EnumWindows(geri_cagir, 0)
        if not bulunan:
            return False

        hwnd = bulunan[0]
        onplan = u32.GetForegroundWindow()
        bizim = u32.GetWindowThreadProcessId(hwnd, None)
        onplandaki = u32.GetWindowThreadProcessId(onplan, None)

        u32.AttachThreadInput(onplandaki, bizim, True)
        u32.ShowWindow(hwnd, 9)          # SW_RESTORE
        u32.SetForegroundWindow(hwnd)
        u32.BringWindowToTop(hwnd)
        u32.AttachThreadInput(onplandaki, bizim, False)
        return True
    except Exception:
        return False


def _alt_surec_pidleri(pid: int) -> set[int]:
    """Verilen surecin altindaki tum surec kimlikleri (kendisi haric)."""
    try:
        cikti = subprocess.run(
            ["powershell", "-NoProfile", "-Command",
             "Get-CimInstance Win32_Process | "
             "Select-Object ProcessId,ParentProcessId | ConvertTo-Csv -NoTypeInformation"],
            capture_output=True, text=True, timeout=15).stdout
    except Exception:
        return set()

    cocuk: dict[int, list[int]] = {}
    for satir in cikti.splitlines()[1:]:
        try:
            p, ebeveyn = (int(x.strip('"')) for x in satir.split(",")[:2])
        except ValueError:
            continue
        cocuk.setdefault(ebeveyn, []).append(p)

    bulunan, yigin = set(), [pid]
    while yigin:
        for c in cocuk.get(yigin.pop(), []):
            if c not in bulunan:
                bulunan.add(c)
                yigin.append(c)
    return bulunan


# Uzerimize binen katmanlari tarayici icinde tek seferde temizleyen betik.
# Python tarafinda tek tek XPath denemekten cok daha hizli ve daha saglam.
_DISMISS_JS = r"""
const ACCEPT = /^(tamam|kabul et|kabul|kapat|anladım|anladim|onayla|devam|×|x)$/i;
const CONTAINER_SEL = [
  '.modal.show', '.modal.in', '.swal2-container', '.sweet-alert',
  '.ui-dialog', '[role="dialog"]', '[class*="cookie" i]', '[id*="cookie" i]',
  '[class*="cerez" i]', '[id*="cerez" i]', '[class*="cerezPolitika" i]',
  '[class*="popup" i]', '[id*="popup" i]', '[class*="duyuru" i]',
  '[id*="duyuru" i]', '[class*="anket" i]', '[id*="anket" i]'
].join(',');

function visible(el) {
  const r = el.getBoundingClientRect();
  if (r.width === 0 || r.height === 0) return false;
  const s = getComputedStyle(el);
  return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
}

const dismissed = [];

// Cerez bandi: once siteye "kabul" diyelim ki acceptCookies cerezi yazilsin.
for (const sel of ['#cookie-notice .acceptcookies', '#cookie-notice .closecookie']) {
  const btn = document.querySelector(sel);
  if (btn && visible(btn)) { btn.click(); dismissed.push(sel); break; }
}

// Sitenin kendi gizleme mantigi calismiyor: #cookie-notice kabul edildikten
// ve sayfa degistikten sonra bile position:fixed / z-index:999 ile ekranin alt
// ~67 pikselini kapatmaya devam ediyor. Oraya denk gelen bir butonun gercek
// tiklamasi bu banda carpar. Kritik tiklamalari zaten JS ile yapiyoruz ama
// bandi tamamen kaldirmak riski buakiyor --- sadece gorsel bir seritle.
const notice = document.querySelector('#cookie-notice');
if (notice && notice.getBoundingClientRect().height > 0) {
  notice.remove();
  dismissed.push('#cookie-notice (kaldirildi)');
}

for (const container of document.querySelectorAll(CONTAINER_SEL)) {
  if (!visible(container)) continue;
  const buttons = container.querySelectorAll(
    'button, a, input[type=button], input[type=submit], .close, [class*="close" i]');
  for (const btn of buttons) {
    const label = (btn.innerText || btn.value || btn.getAttribute('aria-label') || '').trim();
    if (!ACCEPT.test(label)) continue;
    if (!visible(btn)) continue;
    btn.click();
    dismissed.push(label || '(kapat)');
    break;
  }
}

// Modal kapandigi halde geride kalan ve tiklamalari yutan karartma katmani.
for (const bd of document.querySelectorAll('.modal-backdrop, .ui-widget-overlay')) {
  bd.remove();
  dismissed.push('(backdrop)');
}
document.body.classList.remove('modal-open');

return dismissed;
"""


def dismiss_overlays(driver) -> list[str]:
    """Cerez bandi, duyuru/anket modali gibi katmanlari kapatir.

    Idempotent: hicbir sey yoksa bos liste doner, guvenle tekrar cagrilabilir.
    """
    try:
        return driver.execute_script(_DISMISS_JS) or []
    except Exception:
        return []


_BLOCKER_JS = r"""
// Ekranin ortasindaki noktayi kim kapatiyor? Gorunmez bir katman tiklamalari
// yutuyorsa burada yakalanir.
const el = document.elementFromPoint(innerWidth / 2, innerHeight / 2);
if (!el) return null;
for (let n = el; n && n !== document.body; n = n.parentElement) {
  const s = getComputedStyle(n);
  if ((s.position === 'fixed' || s.position === 'absolute') && +s.zIndex > 100) {
    return (n.className || n.id || n.tagName) + '';
  }
}
return null;
"""


def blocking_overlay(driver) -> str | None:
    """Tiklamalari engelleyen bir katman varsa tanimlayicisini dondurur."""
    try:
        return driver.execute_script(_BLOCKER_JS)
    except Exception:
        return None
