"""Chrome surucusu ve sayfa ustune binen katmanlarin (cerez, duyuru, anket)
temizlenmesi."""

from __future__ import annotations

from selenium import webdriver
from selenium.webdriver.chrome.options import Options


def build_driver(headless: bool = False, page_load_timeout: float = 30.0):
    options = Options()

    # `navigator.webdriver` bayragini ve "otomatik test yazilimi" bilgi cubugunu
    # kaldirir. Bunu tespit kacirmak icin degil, sitenin normal bir tarayiciya
    # davrandigi gibi davranmasi icin yapiyoruz.
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)

    # Chrome'un "Sifre kaydedilsin mi?" kutusu sayfanin ustune biniyor ve
    # kritik anda tiklamalari yiyebiliyor. Sifre yoneticisini tamamen kapat.
    options.add_experimental_option("prefs", {
        "credentials_enable_service": False,
        "profile.password_manager_enabled": False,
        "profile.password_manager_leak_detection": False,
        "autofill.profile_enabled": False,
        "autofill.credit_card_enabled": False,
    })
    options.add_argument("--disable-save-password-bubble")
    options.add_argument("--disable-features=PasswordLeakDetection,AutofillServerCommunication")

    if headless:
        options.add_argument("--headless=new")
        options.add_argument("--window-size=1920,1080")
    else:
        options.add_argument("--start-maximized")

    # Postback'ten sonra tum alt kaynaklarin yuklenmesini beklemeyelim; DOM
    # hazir oldugu anda kontrole gecmek kritik anda saniye kazandiriyor.
    options.page_load_strategy = "eager"

    driver = webdriver.Chrome(options=options)
    driver.set_page_load_timeout(page_load_timeout)

    # Onbellegi tamamen kapat. Acilis aninda saniyede birkac kez ayni adresi
    # istiyoruz; Chrome bunlardan birine bayat bir kopya dondurursa seansi
    # gormeden gecebiliriz. Kritik anda bant genisligi degil tazelik onemli.
    try:
        driver.execute_cdp_cmd("Network.setCacheDisabled", {"cacheDisabled": True})
    except Exception:
        pass

    return driver


# Uzerimize binen katmanlari tarayici icinde tek seferde temizleyen betik.
# Python tarafinda tek tek XPath denemekten cok daha hizli ve daha saglam.
_DISMISS_JS = r"""
const ACCEPT = /^(tamam|kabul et|kabul|kapat|anladım|anladim|onayla|devam|×|x)$/i;
const CONTAINER_SEL = [
  '.modal.show', '.modal.in', '.swal2-container', '.sweet-alert',
  '.ui-dialog', '[role="dialog"]', '[class*="cookie" i]', '[id*="cookie" i]',
  '[class*="cerez" i]', '[id*="cerez" i]', '[class*="cerezPolitika" i]',
  '[class*="popup" i]', '[id*="popup" i]', '[class*="duyuru" i]',
  '[id*="duyuru" i]', '[class*="anket" i]', '[id*="anket" i]'
].join(',');

function visible(el) {
  const r = el.getBoundingClientRect();
  if (r.width === 0 || r.height === 0) return false;
  const s = getComputedStyle(el);
  return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
}

const dismissed = [];

// Cerez bandi: once siteye "kabul" diyelim ki acceptCookies cerezi yazilsin.
for (const sel of ['#cookie-notice .acceptcookies', '#cookie-notice .closecookie']) {
  const btn = document.querySelector(sel);
  if (btn && visible(btn)) { btn.click(); dismissed.push(sel); break; }
}

// Sitenin kendi gizleme mantigi calismiyor: #cookie-notice kabul edildikten
// ve sayfa degistikten sonra bile position:fixed / z-index:999 ile ekranin alt
// ~67 pikselini kapatmaya devam ediyor. Oraya denk gelen bir butonun gercek
// tiklamasi bu banda carpar. Kritik tiklamalari zaten JS ile yapiyoruz ama
// bandi tamamen kaldirmak riski buakiyor --- sadece gorsel bir seritle.
const notice = document.querySelector('#cookie-notice');
if (notice && notice.getBoundingClientRect().height > 0) {
  notice.remove();
  dismissed.push('#cookie-notice (kaldirildi)');
}

for (const container of document.querySelectorAll(CONTAINER_SEL)) {
  if (!visible(container)) continue;
  const buttons = container.querySelectorAll(
    'button, a, input[type=button], input[type=submit], .close, [class*="close" i]');
  for (const btn of buttons) {
    const label = (btn.innerText || btn.value || btn.getAttribute('aria-label') || '').trim();
    if (!ACCEPT.test(label)) continue;
    if (!visible(btn)) continue;
    btn.click();
    dismissed.push(label || '(kapat)');
    break;
  }
}

// Modal kapandigi halde geride kalan ve tiklamalari yutan karartma katmani.
for (const bd of document.querySelectorAll('.modal-backdrop, .ui-widget-overlay')) {
  bd.remove();
  dismissed.push('(backdrop)');
}
document.body.classList.remove('modal-open');

return dismissed;
"""


def dismiss_overlays(driver) -> list[str]:
    """Cerez bandi, duyuru/anket modali gibi katmanlari kapatir.

    Idempotent: hicbir sey yoksa bos liste doner, guvenle tekrar cagrilabilir.
    """
    try:
        return driver.execute_script(_DISMISS_JS) or []
    except Exception:
        return []


_BLOCKER_JS = r"""
// Ekranin ortasindaki noktayi kim kapatiyor? Gorunmez bir katman tiklamalari
// yutuyorsa burada yakalanir.
const el = document.elementFromPoint(innerWidth / 2, innerHeight / 2);
if (!el) return null;
for (let n = el; n && n !== document.body; n = n.parentElement) {
  const s = getComputedStyle(n);
  if ((s.position === 'fixed' || s.position === 'absolute') && +s.zIndex > 100) {
    return (n.className || n.id || n.tagName) + '';
  }
}
return null;
"""


def blocking_overlay(driver) -> str | None:
    """Tiklamalari engelleyen bir katman varsa tanimlayicisini dondurur."""
    try:
        return driver.execute_script(_BLOCKER_JS)
    except Exception:
        return None
