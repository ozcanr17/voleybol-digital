# Saha Kiralama Otomasyonu

online.spor.istanbul üzerinde seans açılır açılmaz sahayı sepete ekler.
Voleybol dışında (basketbol, futbol) da kullanılabilir — branş/tesis/salon
ve kiralama türü arayüzden serbestçe girilir.

## Çalıştırma

**Windows:** `baslat.bat` dosyasına çift tıklayın.
**macOS:** Terminal'de bir kez `chmod +x baslat.command`, sonra çift tıklayın.

Bu dosyalar Python'u bulur, sanal ortamı kurar, paketleri indirir ve uygulamayı
başlatır. Python ya da Chrome eksikse ne yapmanız gerektiğini adım adım yazar.
İlk çalıştırma birkaç dakika sürer, sonrakiler saniyeler.

Elle yapmak isterseniz:

```bash
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt   # Windows
.venv\Scripts\python run.py
```

Tarayıcıda `http://127.0.0.1:8777` açılır. Sağ alttaki **Sistem kontrolü**
paneli Python, Chrome, sürücü, site erişimi ve saat farkını kontrol edip
otomasyonun bu bilgisayarda çalışıp çalışamayacağını söyler.

Formu doldurup **Başlat**'a basın. Uygulama giriş yapar, filtreleri seçer,
açılış anına kadar bekler, seans görünür görünmez tıklar ve sepete ekler.

### Bilgilerin saklanması

**Beni hatırla** işaretliyse T.C. no ve şifre yalnızca **tarayıcının yerel
deposunda** tutulur — proje klasörüne, bir dosyaya veya sunucuya yazılmaz, bu
yüzden yanlışlıkla GitHub'a gitmesi mümkün değildir. Ortak kullanılan bir
bilgisayarda işaretlemeyin; **Kayıtlıyı sil** ile her an temizleyebilirsiniz.

Tesis, salon, saat gibi gizli olmayan alanlar her hâlükârda hatırlanır.

## Dağıtım — voleybol.digital/saha-kirala

Kurulum sayfası yayında: **https://voleybol.digital/saha-kirala**

Sayfa statik (GitHub Pages), ama ziyaretçinin bilgisayarında otomasyonun kurulu
olup olmadığını algılıyor: `http://127.0.0.1:8777/api/onkontrol` adresine istek
atıyor, cevap gelirse "kurulu ve hazır" diyor. Bir web sayfasının bilgisayarı
incelemesine tarayıcı izin vermez; meşru olan tek yol budur.

Kurulu değilse işletim sistemine göre sihirbazı sunuyor (`kur.bat` / `kur.command`).
Sihirbaz Python ve Chrome'u kontrol edip eksikse kuruyor, uygulamayı indiriyor,
sanal ortamı hazırlıyor ve masaüstüne kısayol koyuyor.

### Algılamayı mümkün kılan izin

`server.py` içindeki `kisitli_cors` ara katmanı, sadece
`voleybol.digital` kaynağına ve sadece **durum okuyan iki uca**
(`/api/onkontrol`, `/api/status`) izin verir. İşi başlatan uçlar dışarıdan
çağrılamaz — aksi halde ziyaret edilen herhangi bir kötü niyetli sayfa buradaki
otomasyonu sürebilirdi.

Sayfayı başka bir adreste denemek için:
`SAHA_EXTRA_ORIGINS="http://localhost:5500" python run.py`

### Paketi yeniden derlemek

Kodda değişiklik yapınca `saha-kiralama.zip`'i yenileyip `voleybol-digital`
deposundaki `saha-kirala/indir/` klasörüne kopyalayın. Zip'e girenler:
`app/`, `run.py`, `requirements.txt`, `README.md`, `baslat.*`, `tanilama.js`.
`.venv/` ve `__pycache__/` **girmemeli**.

> `.bat` dosyaları CRLF, `.command` dosyaları LF satır sonuyla kalmalı.
> CMD.EXE, `goto` ve parantezli blok içeren LF satır sonlu batch dosyalarında
> hatalı davranır; bash ise CRLF görünce `bad interpreter: /bin/bash^M` hatası
> verir. Depoda `.gitattributes` ile sabitlendi — `.bat` için `-text`, çünkü git
> metin dosyalarını daima LF saklar ve GitHub Pages dosyayı depodaki haliyle
> servis eder.

### Neden sunucuda çalıştırmıyoruz

Teknik olarak mümkün ama üç ciddi sorunu var: **(1)** herkesin T.C. no ve şifresi
sunucuya gelir; **(2)** site Cloudflare arkasında, tüm kullanıcılar tek veri
merkezi IP'sinden gelirse engellenme riski çok artar ve engellenirse herkes
birden etkilenir; **(3)** SMS kullanıcının telefonuna gider, sunucuya
yönlendirilmesi yine kullanıcı başına kurulum ister.

## Neden eski script çalışmıyordu

İki bağımsız kusur vardı; ikisi de bu sürümde giderildi.

**1. Arama bir kez tetikleniyordu.** `click_reservation_by_date_and_time` 20 kez
deniyordu ama her denemede aynı, çoktan yüklenmiş DOM'u tarıyordu. Sayfa ASP.NET
WebForms postback'i ile yenilendiği için yeni bir istek atılmadan içerik asla
değişmez. İlk arama boş döndüyse 20 deneme de boşa gidiyordu. Sayfadan çıkıp
tekrar girince seansın görünmesinin sebebi buydu: elle yapılan her giriş yeni
bir istek demek.

Şimdi `snipe()` seansı bulana kadar aramayı **tekrar tekrar tetikliyor**.

**2. Hedef saat yerel saatle bekleniyordu.** Ölçüm sırasında bu bilgisayarın
saati sunucudan **16 saniye ileriydi** (Google ve Cloudflare ile de doğrulandı).
Eski kod `19:00:02`'yi yerel saatle bekliyordu — bu sunucuda `18:59:46` demek,
yani arama seans açılmadan 14 saniye önce tetikleniyordu.

Şimdi `timesync.py` her çalıştırmada sunucunun `Date` başlığından farkı ölçüyor
ve bekleme **sunucu saatine** göre yapılıyor. Fark arayüzde de gösteriliyor.

> Windows saatinizi de düzeltmek isterseniz (yönetici olarak):
> `w32tm /resync /force`

## Açılırken çıkan çerez / duyuru katmanları

`browser.py` içindeki `dismiss_overlays()` her gezinme ve her yoklama
döngüsünde çalışır. Sitede doğrulanan davranış:

- Çerez bandı `#cookie-notice`, kabul butonu `.acceptcookies` (çoğul).
- Kabul edilse ve sayfa değişse bile **band DOM'dan gitmiyor**;
  `position:fixed / z-index:999` ile ekranın alt ~67 pikselini kaplamaya devam
  ediyor. Bu yüzden band tıklandıktan sonra ayrıca DOM'dan kaldırılıyor.
- Kritik tıklamalar zaten `execute_script("arguments[0].click()")` ile yapılıyor;
  JS tıklaması üstteki katmanları delip geçer.

Eski koddaki `confirm_reservation_popup` gizli bir hata taşıyordu:
`//button[contains(.,'Tamam')]` XPath'i çerez bandındaki **Tamam** butonuyla da
eşleşiyordu. Yeni sürümde arama yalnızca modal kapsamında yapılıyor.

## SMS doğrulama kodu

Dört kaynak aynı anda dinlenir, ilk gelen kod kazanır. Elle giriş **her zaman**
açıktır; otomatik kaynak çalışmazsa akış kesilmez.

| Kaynak | Gereken |
|---|---|
| `adb` | Android + USB hata ayıklama açık + Platform Tools kurulu. Telefona uygulama kurmak gerekmez. Windows ve macOS'ta çalışır. |
| `macos` | macOS + iPhone'da "Metin Mesajı Yönlendirme" açık. Terminal'e Tam Disk Erişimi gerekir. |
| `webhook` | Telefondaki herhangi bir SMS yönlendirme uygulaması `POST /api/sms` adresine `{"text": "..."}` gönderir. `python run.py --lan` ile sunucuyu yerel ağa açın. |
| `manual` | Kodu arayüze yazarsınız. |

Kod ayıklama bilerek **dar** tutuldu (`otp.py` içindeki `HINT_RE`): mesajda
"spor istanbul", "doğrulama", "rezervasyon", "seans" gibi bir ipucu yoksa
kod kabul edilmez. Yanlış kod göndermek denemeyi yakabilir; kaçırmak ise sadece
elle girişe düşürür. Gerçek SMS metnini gördükten sonra `HINT_RE`'ye kendi
ipucunuzu ekleyebilirsiniz — elenen mesajlar kayıt panelinde gösterilir.

## Notlar

- Site **Cloudflare** arkasında (`cf_clearance` çerezi). Uygulama giriş ve
  gezinmeyi açılış anından *önce* bitirir, kritik anda yalnızca yoklama yapar.
  `poll_interval`'ı 0.4 sn'nin altına indirmeyin.
- Herhangi bir adımda hata olursa **tarayıcı açık bırakılır**; devralıp elle
  bitirebilirsiniz.
- **Kuru test** kutusu işaretliyken seans bulunur ama sepete eklenmez. Yeni bir
  tesis/saat kombinasyonunu ilk kez denerken bunu kullanın.

## Dosyalar

| Dosya | Görev |
|---|---|
| `run.py` | Başlatıcı |
| `app/server.py` | HTTP uçları |
| `app/static/index.html` | Arayüz |
| `app/runner.py` | İş akışı durum makinesi (ayrı thread) |
| `app/spor.py` | Site akışı — `snipe()` burada |
| `app/browser.py` | Chrome kurulumu + katman temizliği |
| `app/otp.py` | SMS kodu kaynakları |
| `app/timesync.py` | Sunucu saati senkronu |
| `app/models.py` | Form doğrulama, 72 saat hesabı |
