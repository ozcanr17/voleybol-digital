// KULLANIM
// --------
// 1. Chrome'da online.spor.istanbul'a giriş yap.
// 2. Kiralama Yap > branş/tesis/salon seç > Ara. Seans listesi sayfasına gel.
// 3. F12 > Console sekmesi. Konsol "Yapıştırmaya izin ver" derse
//    `allow pasting` yazıp Enter'a bas, sonra bu dosyanın tamamını yapıştır.
// 4. Çıkan JSON'u kopyalayıp bana gönder.
//
// Bu betik sayfada HİÇBİR ŞEY değiştirmez, sadece okur. Kimlik bilgisi,
// çerez veya kişisel veri toplamaz — yalnızca element kimlikleri.

(() => {
  const rapor = {};
  const kisalt = (s, n = 90) => (s || "").replace(/\s+/g, " ").trim().slice(0, n);

  // 1) EN ÖNEMLİSİ: sonuç sayfasında arama butonu var mı?
  //    Varsa açılış anında sayfayı onunla tazeleriz (hızlı yol).
  const aramaBtn = document.getElementById("pageContent_ucUrunArama_lbtnKiralikAra");
  rapor["1_arama_butonu"] = aramaBtn
    ? { var: true, etiket: kisalt(aramaBtn.innerText), href: kisalt(aramaBtn.href, 120) }
    : {
        var: false,
        // Yoksa: sayfadaki diğer "ara" görünümlü kontrolleri listele
        adaylar: [...document.querySelectorAll("a,button,input[type=submit]")]
          .filter((e) => /ara|filtre|listele/i.test(e.innerText || e.value || ""))
          .slice(0, 8)
          .map((e) => ({ tag: e.tagName, id: e.id, metin: kisalt(e.innerText || e.value, 40) })),
      };

  // 2) Seans kartlarının yapısı — tarih paneli, saat etiketi, Rezervasyon linki
  const rezLink = document.querySelector('a[id*="lbRezervasyon"]');
  rapor["2_seans_karti"] = rezLink
    ? {
        rezervasyon_id: rezLink.id,
        rezervasyon_href: kisalt(rezLink.href, 140),
        ust_kart_class: kisalt(rezLink.closest("div[class*='well']")?.className, 80),
        saat_etiketi: kisalt(
          rezLink.closest("div[class*='well']")?.querySelector("span[class*='lblStyle']")?.innerText, 40),
        panel_basligi: kisalt(rezLink.closest("div[class*='panel']")?.querySelector("h3")?.innerText, 40),
      }
    : "Sayfada hiç Rezervasyon linki yok (tüm seanslar dolu olabilir).";

  // 3) Tarih başlıkları gerçekten h3 mü? XPath'lerimiz buna dayanıyor.
  rapor["3_tarih_basliklari"] = [...document.querySelectorAll("div[class*='panel'] h3")]
    .slice(0, 8).map((h) => kisalt(h.innerText, 30));

  // 4) SMS doğrulama alanı ve butonu (sepete ekledikten sonra görünür)
  const otpAlan = document.getElementById("pageContent_txtDogrulamaKodu");
  rapor["4_sms_alani"] = otpAlan
    ? {
        alan_var: true,
        buton: [...document.querySelectorAll("a,button,input[type=submit]")]
          .filter((e) => /doğrula|dogrula/i.test(e.innerText || e.value || ""))
          .map((e) => ({ tag: e.tagName, id: e.id, metin: kisalt(e.innerText || e.value, 30) })),
      }
    : "SMS alanı şu an sayfada yok (sepete ekledikten sonra çıkıyor).";

  // 5) Satış türü dropdown'ı
  rapor["5_satis_turu"] = document.getElementById("select2-ddlSatisTuru-container")
    ? "select2-ddlSatisTuru-container bulundu"
    : "yok (rezervasyon formuna geçince çıkıyor)";

  // 6) Üstümüze binen katmanlar
  rapor["6_katmanlar"] = [...document.querySelectorAll(
    '#cookie-notice,.modal.show,.modal.in,[role="dialog"],[class*="popup" i],[class*="duyuru" i],[class*="anket" i]')]
    .map((e) => ({
      id: e.id, cls: kisalt(e.className, 60),
      yukseklik: Math.round(e.getBoundingClientRect().height),
      pos: getComputedStyle(e).position, z: getComputedStyle(e).zIndex,
      metin: kisalt(e.innerText, 50),
    }));

  // 7) Sunucu ile saat farkı (bu tarayıcıya göre)
  rapor["7_bilgi"] = { url: location.pathname, baslik: kisalt(document.title, 40) };

  const cikti = JSON.stringify(rapor, null, 2);
  console.log(cikti);
  try { copy(rapor); console.log("--> Panoya kopyalandı, doğrudan yapıştırabilirsin."); } catch (e) {}
  return rapor;
})();
